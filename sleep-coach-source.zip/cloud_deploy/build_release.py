"""Build an allowlisted release without touching the installed app or its data."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
from uuid import uuid4
import zipfile

ROOT = Path(__file__).resolve().parent.parent
BACKEND_FILES = (
    "api.py", "health_records.py", "json_sleep.py", "export_times.py",
    "health_export_kit.py", "sleep_accounts.py", "coaching_service.py",
    "history_service.py", "backup_policy.py", "service_limits.py",
    "sleep_alarms.py", "sleep_alarm_popup.py",
)


def build_release(output_root=None):
    output_root = Path(output_root or ROOT / "cloud_deploy" / "artifacts")
    output_root.mkdir(parents=True, exist_ok=True)
    name = "sleep-coach-" + datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S") + "-" + uuid4().hex[:8]
    output = output_root / name
    output.mkdir(exist_ok=False)
    files = {f"mobile_backend/{name}": name for name in BACKEND_FILES}
    files.update({
        "streamlit_clock_update/app.py": "app.py",
        "streamlit_clock_update/apple_watch_ui.py": "apple_watch_ui.py",
        "cloud_deploy/start_cloud.py": "start_cloud.py",
        "cloud_deploy/requirements.txt": "requirements.txt",
        "cloud_deploy/.python-version": ".python-version",
        "cloud_deploy/render.yaml": "render.yaml",
        "cloud_deploy/streamlit-config.toml": ".streamlit/config.toml",
        "cloud_deploy/release.gitignore": ".gitignore",
        "cloud_deploy/README.md": "README.md",
    })
    manifest = {"created_at": datetime.now(timezone.utc).isoformat(), "files": {}}
    for source, target in files.items():
        path = ROOT / source
        if path.is_symlink() or not path.is_file():
            raise ValueError("Release input must be a regular source file: " + source)
        content = path.read_bytes()
        destination = output / target
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(content)
        manifest["files"][target] = hashlib.sha256(content).hexdigest()
    (output / "release_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    archive = output_root / (name + ".zip")
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as package:
        for file in sorted(output.rglob("*")):
            if file.is_file():
                package.write(file, file.relative_to(output).as_posix())
    return output, archive


if __name__ == "__main__":
    output, archive = build_release()
    print("RELEASE_DIRECTORY:", output)
    print("RELEASE_ZIP:", archive)
