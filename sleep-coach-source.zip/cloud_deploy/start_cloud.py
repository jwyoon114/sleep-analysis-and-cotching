"""Start the existing app with a persistent database outside the source tree."""
from contextlib import closing
import os
from pathlib import Path
import sys
import tempfile

APP_ROOT = Path(__file__).resolve().parent


def validate_environment(app_root=APP_ROOT):
    configured = os.environ.get("SLEEP_DATA_DIR", "")
    db_configured = os.environ.get("SLEEP_DB_PATH", "")
    if not configured or not db_configured:
        raise ValueError("SLEEP_DATA_DIR and SLEEP_DB_PATH must name persistent storage.")
    data_dir, db_path = Path(configured), Path(db_configured)
    if not data_dir.is_absolute() or not db_path.is_absolute():
        raise ValueError("Persistent storage paths must be absolute.")
    data_dir, db_path = data_dir.resolve(), db_path.resolve()
    if not data_dir.is_dir():
        raise ValueError("The persistent storage mount is not available.")
    source = app_root.resolve()
    if data_dir == source or source in data_dir.parents:
        raise ValueError("Persistent storage must be outside the application source directory.")
    if not db_path.is_relative_to(data_dir) or db_path == data_dir:
        raise ValueError("SLEEP_DB_PATH must be a file inside SLEEP_DATA_DIR.")
    try:
        port = int(os.getenv("PORT", "10000"))
    except ValueError:
        raise ValueError("PORT must be an integer.") from None
    if not 1 <= port <= 65535:
        raise ValueError("PORT must be between 1 and 65535.")
    # Stop before opening the app if the mount cannot accept writes.
    with tempfile.TemporaryFile(dir=data_dir) as probe:
        probe.write(b"storage-check")
    return db_path, port


def bootstrap(app_root=APP_ROOT):
    if os.name == "posix":
        os.umask(0o077)
    db_path, port = validate_environment(app_root)
    # Imports happen only after the environment has been checked.
    from health_records import connect
    from backup_policy import create_backup, maintain_backups
    from service_limits import setting
    for key in ("COACHING_USER_LIMIT_24H", "COACHING_GLOBAL_LIMIT_24H", "COACHING_MAX_INPUT_BYTES"):
        setting(key, 0)
    if db_path.exists():
        status = create_backup(db_path)
    else:
        with closing(connect(db_path)) as db:
            assert db.execute("PRAGMA foreign_key_check").fetchall() == []
        status = maintain_backups(db_path)
    print(f"CLOUD_STORAGE_READY; managed_backups={status['backup_count']}; pending={status['pending']}", flush=True)
    return port


def main():
    port = bootstrap()
    if "--check-only" in sys.argv:
        return
    arguments = [sys.executable, "-m", "streamlit", "run", str(APP_ROOT / "app.py"),
                 "--server.address=0.0.0.0", f"--server.port={port}",
                 "--server.headless=true", "--browser.gatherUsageStats=false"]
    os.chdir(APP_ROOT)
    os.execv(sys.executable, arguments)


if __name__ == "__main__":
    main()
