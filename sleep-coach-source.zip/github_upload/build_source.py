"""Package only sleep-project source; never traverse the installed app or its data."""
import hashlib
import json
import os
from pathlib import Path
import re
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DIRECTORIES = (
    "mobile_backend", "streamlit_clock_update", "mobile_flutter",
    "desktop_launcher", "free_share", "cloud_deploy", "github_upload",
    "sleep_frontend", "windows_distribution",
)
EXTENSIONS = {".py", ".ps1", ".cmd", ".md", ".txt", ".dart", ".yaml", ".toml", ".xml", ".ts", ".tsx", ".css", ".mjs", ".js", ".html"}
SKIP = {"__pycache__", ".venv", "venv", "bin", "artifacts", "data", "build", ".dart_tool", ".sleep-share", ".streamlit", "node_modules", ".next", ".next-test", ".runtime", ".git"}
SPECIAL = {"cloud_deploy/.python-version", "cloud_deploy/release.gitignore", "mobile_backend/examples/sleep_example.json",
           "sleep_frontend/package.json", "sleep_frontend/package-lock.json", "sleep_frontend/tsconfig.json", "sleep_frontend/.env.example", "sleep_frontend/.gitignore"}
SPECIAL.update('sleep_frontend/public/icons/'+name for name in ('app-192.png','app-512.png','app-maskable.png','apple-touch-icon.png'))
SECRET = re.compile(r"(?:sk-(?:proj-)?[A-Za-z0-9_-]{24,}|gh[pousr]_[A-Za-z0-9]{30,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)")


def build():
    sources = [ROOT / "README.md", ROOT / ".gitignore"]
    for directory in DIRECTORIES:
        for folder, directories, filenames in os.walk(ROOT / directory, followlinks=False):
            directories[:] = [name for name in directories if name not in SKIP]
            for name in directories:
                if (Path(folder) / name).is_symlink():
                    raise ValueError("Symbolic link directory is not packaged.")
            for name in filenames:
                path = Path(folder) / name
                relative = path.relative_to(ROOT)
                if path.is_symlink():
                    raise ValueError("Symbolic links are not packaged: " + str(relative))
                if path.name == "next-env.d.ts":
                    continue
                if path.suffix.lower() in EXTENSIONS or relative.as_posix() in SPECIAL:
                    sources.append(path)
    files = {}
    for path in sorted(sources):
        raw = path.read_bytes()
        if path.suffix != '.png' and SECRET.search(raw.decode("utf-8-sig")):
            raise ValueError("Possible secret; upload stopped: " + path.relative_to(ROOT).as_posix())
        files[path.relative_to(ROOT).as_posix()] = raw
    output = ROOT / "github_upload" / "artifacts"
    output.mkdir(parents=True, exist_ok=True)
    archive = output / "sleep-coach-source.zip"
    manifest = {name: hashlib.sha256(raw).hexdigest() for name, raw in files.items()}
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as package:
        for name, raw in files.items():
            package.writestr(name, raw)
        package.writestr("source_manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2))
    with zipfile.ZipFile(archive) as package:
        assert package.testzip() is None
        for name, digest in manifest.items():
            assert hashlib.sha256(package.read(name)).hexdigest() == digest
    print("SOURCE_FILES:", len(files))
    print("ZIP_VERIFIED:", archive)


if __name__ == "__main__":
    build()
