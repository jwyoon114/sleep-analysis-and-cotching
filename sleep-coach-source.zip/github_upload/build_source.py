"""Package only sleep-project source; never traverse the installed app or its data."""
import hashlib
import json
from pathlib import Path
import re
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DIRECTORIES = (
    "mobile_backend", "streamlit_clock_update", "mobile_flutter",
    "desktop_launcher", "free_share", "cloud_deploy", "github_upload",
)
EXTENSIONS = {".py", ".ps1", ".md", ".txt", ".dart", ".yaml", ".toml", ".xml"}
SKIP = {"__pycache__", ".venv", "venv", "bin", "artifacts", "data", "build", ".dart_tool", ".sleep-share", ".streamlit"}
SPECIAL = {"cloud_deploy/.python-version", "cloud_deploy/release.gitignore", "mobile_backend/examples/sleep_example.json"}
SECRET = re.compile(r"(?:sk-(?:proj-)?[A-Za-z0-9_-]{24,}|gh[pousr]_[A-Za-z0-9]{30,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)")


def build():
    sources = [ROOT / "README.md", ROOT / ".gitignore"]
    for directory in DIRECTORIES:
        for path in (ROOT / directory).rglob("*"):
            relative = path.relative_to(ROOT)
            if path.is_symlink():
                raise ValueError("Symbolic links are not packaged: " + str(relative))
            if not path.is_file() or SKIP.intersection(relative.parts):
                continue
            if path.suffix.lower() in EXTENSIONS or relative.as_posix() in SPECIAL:
                sources.append(path)
    files = {}
    for path in sorted(sources):
        raw = path.read_bytes()
        if SECRET.search(raw.decode("utf-8-sig")):
            raise ValueError("Possible secret; upload stopped: " + path.relative_to(ROOT).as_posix())
        files[path.relative_to(ROOT).as_posix()] = raw
    output = ROOT / "github_upload" / "artifacts"
    output.mkdir(parents=True, exist_ok=True)
    archive = output / "sleep-coach-source.zip"
    manifest = {name: hashlib.sha256(raw).hexdigest() for name, raw in files.items()}
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as package:
        for name, raw in files.items():
            package.writestr(name, raw)
        package.writestr("source_manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2))
    with zipfile.ZipFile(archive) as package:
        assert package.testzip() is None
        for name, digest in manifest.items():
            assert hashlib.sha256(package.read(name)).hexdigest() == digest
    print("SOURCE_FILES:", len(files))
    print("ZIP_VERIFIED:", archive)


if __name__ == "__main__":
    build()
