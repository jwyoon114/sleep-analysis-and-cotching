"""Stage the current wearable app as readable Python files, without runtime data."""
from pathlib import Path
import hashlib
import re
import shutil

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "github_upload" / "artifacts" / "python-source"
SOURCES = {
    **{name: ROOT / "mobile_backend" / name for name in (
        "api.py", "health_records.py", "json_sleep.py", "export_times.py",
        "health_export_kit.py", "sleep_accounts.py", "coaching_service.py",
        "service_limits.py", "history_service.py", "backup_policy.py",
        "requirements-mobile.txt",
        "sleep_alarms.py", "sleep_alarm_popup.py",
    )},
    "app.py": ROOT / "streamlit_clock_update" / "app.py",
    "apple_watch_ui.py": ROOT / "streamlit_clock_update" / "apple_watch_ui.py",
    "launch_sleep_app.py": ROOT / "desktop_launcher" / "launch_sleep_app.py",
    "share_sleep_app.py": ROOT / "free_share" / "share_sleep_app.py",
}
SECRET = re.compile(r"(?:sk-(?:proj-)?[A-Za-z0-9_-]{24,}|gh[pousr]_[A-Za-z0-9]{30,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)")

def main():
    OUTPUT.mkdir(parents=True, exist_ok=True)
    for name, source in SOURCES.items():
        content = source.read_text(encoding="utf-8-sig")
        if SECRET.search(content):
            raise ValueError("Possible secret in " + name)
        if source.suffix == ".py":
            compile(content, name, "exec")
        shutil.copy2(source, OUTPUT / name)
        assert hashlib.sha256(source.read_bytes()).digest() == hashlib.sha256((OUTPUT / name).read_bytes()).digest()
    (OUTPUT / "PYTHON_README.md").write_text("""# Python 프로그램 실행 안내

저장소 루트의 `.py` 파일은 현재 사용하는 웨어러블 수면 분석·AI 코칭 프로그램입니다.
최근 추가한 분석 직후 시간별 수면 단계 그래프와 과거 기록 그래프가 포함되어 있습니다.
매일 반복 취침·기상 PC 알람과 AI 제안 시간 불러오기, API 오류별 안내도 포함합니다.
이 파일들과 `requirements-mobile.txt`를 같은 폴더에 두고 실행하세요.

## 설치 및 실행 (Windows, Python 3.11 이상)

```powershell
python -m venv .venv
.\\.venv\\Scripts\\python.exe -m pip install -r requirements-mobile.txt
.\\.venv\\Scripts\\python.exe -m streamlit run app.py
```

브라우저에 표시되는 주소로 접속하면 회원가입 후 사용할 수 있습니다.
새 PC에는 새 데이터베이스가 생성됩니다.
계정, 비밀번호, 실제 수면 기록, API 키는 소스에 포함하지 않습니다.
AI 코칭을 사용하려면 자신의 `OPENAI_API_KEY`를 서버 환경변수로 설정하세요.
AI 코칭에는 별도 API 사용료가 발생하며, 키 없이도 기록 분석과 저장은 가능합니다.

## 주요 파일

- `app.py`: 프로그램 시작
- `apple_watch_ui.py`: 분석·그래프·기록·계정 화면
- `health_records.py`, `json_sleep.py`: 기록 분석 및 저장
- `sleep_accounts.py`: 회원가입·로그인·계정 관리
- `coaching_service.py`: AI 코칭
- `history_service.py`, `backup_policy.py`: 기록·휴지통·백업 관리
- `api.py`: 모바일 및 웹 프론트엔드용 API
- `launch_sleep_app.py`, `share_sleep_app.py`: Windows 실행·무료 공유 도구

알람은 Windows PC와 프로그램 서버가 켜져 있을 때만 해당 PC에서 울립니다. 휴대폰 알람이 아닙니다.
전체 프로젝트는 최신 `sleep-coach-source.zip`, Windows 웹앱 설치는 `daljam-windows-setup.zip`을 참고하세요.
Next.js 프론트엔드와 Flutter 앱은 별도 프로젝트이며 이 Python 실행 절차에 필요하지 않습니다.
""", encoding="utf-8")
    print("VERIFIED_PYTHON_FILES", sum(name.endswith(".py") for name in SOURCES))
    print("UPLOAD_FILES", len(SOURCES) + 1)

if __name__ == "__main__":
    main()
