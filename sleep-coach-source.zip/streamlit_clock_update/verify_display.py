"""UI regression check with a metadata fixture; no EEG inference or API calls."""
import csv
from datetime import datetime, timezone
from io import BytesIO
from pathlib import Path
import sys
from types import ModuleType, SimpleNamespace
from unittest.mock import patch

import numpy as np
import streamlit as st
from streamlit.testing.v1 import AppTest


FOLDER = Path(__file__).resolve().parent
sys.path.insert(0, str(FOLDER))
PROJECT = Path(r"C:\Users\jwyoo\Desktop\인하대 2-2\PythonProject1")
source = PROJECT / "data" / "SC4001E0-PSG.edf"
with source.open("rb") as file:
    header = file.read(256)
day, month, year = map(int, header[168:176].decode("ascii").split("."))
hour, minute, second = map(int, header[176:184].decode("ascii").split("."))
clock = datetime(1900 + year, month, day, hour, minute, second, tzinfo=timezone.utc)
seconds = int(header[236:244]) * float(header[244:252])
fixture = {"clock": clock}


def raw_header(*args, **kwargs):
    return SimpleNamespace(
        ch_names=["EEG Fpz-Cz"],
        info={"sfreq": 100.0, "meas_date": fixture["clock"]},
        n_times=int(seconds * 100), close=lambda: None,
    )


fake_mne = ModuleType("mne")
fake_mne.io = SimpleNamespace(read_raw_edf=raw_header)
fake_predict = ModuleType("predict")
fake_predict.BANDS = dict(delta=(0.5, 4), theta=(4, 8), alpha=(8, 12), sigma=(12, 16), beta=(16, 30))
fake_predict.STAGE_NAMES = {1: "W", 2: "N1", 3: "N2", 4: "N3", 5: "REM"}
fake_predict.extract_features = lambda *args: None
fake_coach = ModuleType("coach")


def no_api(**kwargs):
    raise AssertionError("UI test must not call OpenAI")


fake_coach.generate_coaching = no_api
uploaded = BytesIO(b"metadata fixture")
uploaded.name = source.name

with patch.dict(sys.modules, {
    "mne": fake_mne, "predict": fake_predict, "coach": fake_coach,
}), patch.object(st, "file_uploader", return_value=uploaded):
    at = AppTest.from_file(str(FOLDER / "app.py")).run(timeout=40)
    assert not at.exception, at.exception
    assert at.metric[0].value == "04/24 16:13:00"
    assert at.metric[1].value == "04/25 14:18:00"
    assert at.metric[2].value == "22시간 5분"

    label_map = {v: k for k, v in fake_predict.STAGE_NAMES.items()}
    with (PROJECT / "results" / "SC4001E0-PSG_predictions.csv").open(encoding="utf-8-sig") as file:
        predictions = np.array([label_map[row["predicted_stage"]] for row in csv.DictReader(file)])
    at.session_state["analysis_result"] = {
        "schema_version": 2, "filename": source.name, "predictions": predictions,
        "start_minutes": 0.0, "end_minutes": 1325.0,
        "recording_start": clock.replace(tzinfo=None), "recording_seconds": seconds,
    }
    at.run(timeout=40)
    assert not at.exception, at.exception
    assert at.metric[4].value == "6시간 55분 30초"
    assert any(frame.value.iloc[0, 0] == "깨어 있음 (W)" for frame in at.dataframe)
    assert any("1989-04-24" in item.value for item in at.caption)
    from display_time import prediction_intervals
    intervals = prediction_intervals(predictions, 0, clock)
    total_sleep = sum(item["duration_seconds"] for item in intervals if item["state"] == "sleep")
    total_wake = sum(item["duration_seconds"] for item in intervals if item["state"] == "wake")
    assert total_sleep / 60 == 415.5
    assert total_wake / 60 == 909.5
    assert any(tab.label.startswith("잠으로 예측한 구간") for tab in at.tabs)
    assert any("예측 상태" in frame.value.columns for frame in at.dataframe)
    print("SLEEP_WAKE_INTERVAL_UI_OK")
    print("UPLOADED_FILE_AND_RESULT_UI_OK")

    del at.session_state["analysis_result"]
    fixture["clock"] = None
    at.run(timeout=40)
    assert not at.exception, at.exception
    assert at.metric[0].value == "시각 정보 없음"
    assert at.metric[1].value == "시각 정보 없음"
    print("MISSING_TIMESTAMP_UI_OK")

    from display_time import prediction_intervals
    midnight = datetime(2026, 11, 4, 23, 58)
    runs = prediction_intervals([1, 1, 2, 3, 5, 1, 4, 4], 0, midnight)
    assert len(runs) == 4
    assert runs[1]["시작 시각"] == "2026-11-04 23:59:00"
    assert runs[1]["종료 시각"] == "2026-11-05 00:00:30"
    assert [run["duration_seconds"] for run in runs] == [60, 90, 30, 60]
    assert prediction_intervals([], 0, midnight) == []
    assert len(prediction_intervals([2, 3, 4, 5], 0, midnight)) == 1
    assert len(prediction_intervals([1, 1], 0, midnight)) == 1
    assert prediction_intervals([2], 10, None)[0]["start_seconds"] == 600
    print("INTERVAL_EDGE_CASES_OK")
