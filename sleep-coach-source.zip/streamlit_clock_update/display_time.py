"""Present EDF wall-clock metadata without inventing a timezone or sleep onset."""
from datetime import datetime, timedelta
import math


STAGE_LABELS = {
    "W": "깨어 있음 (W)",
    "N1": "얕은 수면 1단계 (N1)",
    "N2": "얕은 수면 2단계 (N2)",
    "N3": "깊은 수면 (N3)",
    "REM": "렘수면 (REM)",
}


def duration_text(minutes):
    if not math.isfinite(float(minutes)) or float(minutes) < 0:
        raise ValueError("기록 길이가 올바르지 않습니다.")
    seconds = int(round(float(minutes) * 60))
    hours, remaining = divmod(seconds, 3600)
    mins, secs = divmod(remaining, 60)
    parts = []
    if hours:
        parts.append(f"{hours}시간")
    if mins or not parts:
        parts.append(f"{mins}분")
    if secs:
        parts.append(f"{secs}초")
    return " ".join(parts)


def stored_clock(value):
    if value is None:
        return None
    if isinstance(value, str):
        value = datetime.fromisoformat(value)
    if not isinstance(value, datetime):
        return None
    # MNE represents EDF header clock values with UTC tzinfo. EDF itself does not
    # establish the original timezone. Preserve the stored clock; do not add 9h.
    return value.replace(tzinfo=None)


def time_at(start, offset_seconds=0):
    clock = stored_clock(start)
    return None if clock is None else clock + timedelta(seconds=float(offset_seconds))


def clock_text(start, offset_seconds=0, include_year=False):
    value = time_at(start, offset_seconds)
    if value is None:
        return "시각 정보 없음"
    pattern = "%Y-%m-%d %H:%M:%S" if include_year else "%m/%d %H:%M:%S"
    return value.strftime(pattern)


def csv_clock(start, offset_seconds=0):
    value = time_at(start, offset_seconds)
    return "" if value is None else value.isoformat(timespec="seconds")


def prediction_intervals(predictions, start_minutes, recording_start):
    """Merge adjacent sleep/wake epochs without smoothing or dropping brief runs.

    N1/N2/N3/REM are all sleep. Transitions among them do not split a sleep run.
    End times are exclusive boundaries after the last 30-second epoch.
    """
    if not math.isfinite(float(start_minutes)) or float(start_minutes) < 0:
        raise ValueError("분석 시작 시간이 올바르지 않습니다.")
    labels = list(predictions)
    if not labels:
        return []
    if any(label not in {1, 2, 3, 4, 5} for label in labels):
        raise ValueError("알 수 없는 수면 단계가 있습니다.")

    def display(seconds):
        if stored_clock(recording_start) is not None:
            return clock_text(recording_start, seconds, include_year=True)
        return f"기록 시작 후 {duration_text(seconds / 60)}"

    intervals = []
    run_start = 0
    sleeping = labels[0] != 1
    for index in range(1, len(labels) + 1):
        if index < len(labels) and (labels[index] != 1) == sleeping:
            continue
        begin = float(start_minutes) * 60 + run_start * 30
        end = float(start_minutes) * 60 + index * 30
        intervals.append({
            "state": "sleep" if sleeping else "wake",
            "start_seconds": begin,
            "end_seconds": end,
            "duration_seconds": end - begin,
            "시작 시각": display(begin),
            "종료 시각": display(end),
            "지속 시간": duration_text((end - begin) / 60),
        })
        if index < len(labels):
            run_start = index
            sleeping = labels[index] != 1
    return intervals
