"""Measure local imports and synthetic DB reads without real health data or API calls."""
from contextlib import closing
import json
from pathlib import Path
import statistics
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "mobile_backend"))
from health_records import connect
from history_service import expire_trash


def main():
    snippet = ("import sys,time; sys.path[:0]=" + repr([str(ROOT / "mobile_backend"), str(ROOT / "streamlit_clock_update")])
               + "; import streamlit; t=time.perf_counter(); import apple_watch_ui; print(time.perf_counter()-t)")
    imports = [float(subprocess.check_output([sys.executable, "-B", "-c", snippet], text=True).strip()) for _ in range(3)]
    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / "synthetic.sqlite3"
        with closing(connect(path)) as db, db:
            db.executemany("INSERT INTO sessions VALUES(?,?,?,?,?)", [(str(i), "synthetic", "2026-01-01", "2026-01-02", json.dumps({"synthetic_padding": "x" * 50000})) for i in range(1000)])
            db.executemany("INSERT INTO trash_sessions VALUES(?,?,?)", [(str(i), "synthetic", "2099-01-01T00:00:00+00:00") for i in range(1000)])
        t = time.perf_counter()
        for _ in range(100):
            connect(path).close()
        connections = (time.perf_counter() - t) / 100
        t = time.perf_counter()
        expire_trash("synthetic", path)
        expiry = time.perf_counter() - t
    print(json.dumps({"dashboard_import_seconds_median": statistics.median(imports), "db_connect_seconds_mean": connections,
                      "trash_check_1000_records_seconds": expiry}, indent=2))


if __name__ == "__main__":
    main()
