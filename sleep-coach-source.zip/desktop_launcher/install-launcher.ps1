﻿param([Parameter(Mandatory = $true)][string]$ProjectPath)
$ErrorActionPreference = 'Stop'
$project = (Resolve-Path -LiteralPath $ProjectPath).Path
$pythonw = Join-Path $project '.venv\Scripts\pythonw.exe'
if (-not (Test-Path -LiteralPath $pythonw) -or -not (Test-Path -LiteralPath (Join-Path $project 'app.py'))) {
    throw 'Install the app and its .venv environment first.'
}
$source = Join-Path $PSScriptRoot 'launch_sleep_app.py'
$target = Join-Path $project 'launch_sleep_app.py'
if ($source -ne $target) {
    if (Test-Path -LiteralPath $target) {
        if ((Get-FileHash -LiteralPath $source).Hash -ne (Get-FileHash -LiteralPath $target).Hash) {
            Copy-Item -LiteralPath $target -Destination ($target + '.before-launcher-' + [guid]::NewGuid().ToString('N') + '.bak')
        }
    }
    Copy-Item -LiteralPath $source -Destination $target -Force
}
$shell = New-Object -ComObject WScript.Shell
$desktopDirectory = [Environment]::GetFolderPath('Desktop')
foreach ($action in @(@('수면 리포트 실행.lnk', ''), @('수면 리포트 종료.lnk', ' --stop'))) {
    $shortcut = $shell.CreateShortcut((Join-Path $desktopDirectory $action[0]))
    $shortcut.TargetPath = $pythonw
    $shortcut.Arguments = '"' + $target + '"' + $action[1]
    $shortcut.WorkingDirectory = $project
    $shortcut.WindowStyle = 7
    $shortcut.IconLocation = $pythonw + ',0'
    $shortcut.Description = '수면 기록 분석과 AI 코칭 앱'
    $shortcut.Save()
}
foreach ($name in @('수면 리포트 실행.lnk', '수면 리포트 종료.lnk')) {
    $shortcut = $shell.CreateShortcut((Join-Path $desktopDirectory $name))
    if ($shortcut.TargetPath -ne $pythonw -or $shortcut.WorkingDirectory -ne $project) {
        throw 'Shortcut verification failed.'
    }
}
Write-Output 'DESKTOP_SHORTCUTS_VERIFIED'
