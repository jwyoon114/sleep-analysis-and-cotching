"""Read-only HTTPS and Streamlit WebSocket check; no real login or paid API."""
import argparse
import asyncio
import re
import urllib.request

from streamlit.proto.BackMsg_pb2 import BackMsg
from streamlit.proto.ForwardMsg_pb2 import ForwardMsg
from websockets.asyncio.client import connect


async def check_login(url):
    connection = await connect(url.replace("https://", "wss://", 1) + "/_stcore/stream",
                               origin=url, subprotocols=["streamlit"], open_timeout=15)
    labels = []
    frames = []
    try:
        request = BackMsg()
        request.rerun_script.query_string = ""
        request.rerun_script.context_info.timezone = "Asia/Seoul"
        request.rerun_script.context_info.locale = "ko-KR"
        request.rerun_script.context_info.url = url
        await connection.send(request.SerializeToString())
        for _ in range(150):
            try:
                raw = await asyncio.wait_for(connection.recv(), timeout=20)
            except TimeoutError:
                raise RuntimeError(f"Timed out waiting for login render; frames={frames}; input_count={len(labels)}") from None
            if raw is None:
                raise RuntimeError("Public WebSocket closed before rendering login.")
            message = ForwardMsg()
            message.ParseFromString(raw)
            frames.append(message.WhichOneof("type"))
            if message.HasField("delta") and message.delta.HasField("new_element"):
                element = message.delta.new_element
                if element.HasField("exception"):
                    raise RuntimeError("Public app returned a script error.")
                if element.HasField("text_input"):
                    labels.append(element.text_input.label)
            if len(labels) >= 5 or message.WhichOneof("type") == "script_finished":
                break
        assert len(labels) == 5, "Public login/register inputs were not rendered."
        assert "아이디" in labels and "비밀번호" in labels
        print("PUBLIC_WEBSOCKET_LOGIN_RENDER_OK")
    finally:
        await connection.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("url")
    args = parser.parse_args()
    if not re.fullmatch(r"https://[a-z0-9]+(?:-[a-z0-9]+)*\.trycloudflare\.com", args.url):
        raise ValueError("A verified Quick Tunnel HTTPS URL is required.")
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open(args.url + "/_stcore/health", timeout=15) as response:
        assert response.status == 200 and response.read(16).strip() == b"ok"
    print("PUBLIC_HTTPS_HEALTH_OK")
    asyncio.run(check_login(args.url))


if __name__ == "__main__":
    main()
