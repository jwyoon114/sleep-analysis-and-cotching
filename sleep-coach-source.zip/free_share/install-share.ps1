param([string]$ProjectPath = 'C:\Users\jwyoo\Desktop\인하대 2-2\PythonProject1')
$ErrorActionPreference = 'Stop'
$project = (Resolve-Path -LiteralPath $ProjectPath).Path
if (-not (Test-Path -LiteralPath (Join-Path $project 'app.py'))) { throw 'Sleep app not found.' }
& (Join-Path $PSScriptRoot 'download-cloudflared.ps1')
$shareDirectory = Join-Path $project '.sleep-share'
New-Item -ItemType Directory -Path $shareDirectory -Force | Out-Null
$binary = Join-Path $shareDirectory 'cloudflared-2026.10.7.exe'
if (-not (Test-Path -LiteralPath $binary)) {
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'bin\cloudflared-2026.10.7.exe') -Destination $binary
}
if ((Get-FileHash -LiteralPath $binary -Algorithm SHA256).Hash.ToLowerInvariant() -ne '2493dbc168923bb3e59e5e7716f71deced92992eea9acd6e9d74f84ac7751343') {
    throw 'Installed Cloudflare SHA256 mismatch.'
}
$target = Join-Path $project 'share_sleep_app.py'
if (Test-Path -LiteralPath $target) {
    Copy-Item -LiteralPath $target -Destination ($target + '.before-share-' + [guid]::NewGuid().ToString('N') + '.bak')
}
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'share_sleep_app.py') -Destination $target
$shell = New-Object -ComObject WScript.Shell
$desktopDirectory = [Environment]::GetFolderPath('Desktop')
foreach ($action in @(@('수면 앱 인터넷 공유 시작.lnk', ''), @('수면 앱 인터넷 공유 중지.lnk', ' --stop'))) {
    $shortcut = $shell.CreateShortcut((Join-Path $desktopDirectory $action[0]))
    $shortcut.TargetPath = Join-Path $project '.venv\Scripts\pythonw.exe'
    $shortcut.Arguments = '"' + $target + '"' + $action[1]
    $shortcut.WorkingDirectory = $project
    $shortcut.WindowStyle = 7
    $shortcut.Description = '무료 임시 주소로 수면 앱 공유. PC가 켜져 있어야 하며 재시작하면 주소가 바뀝니다.'
    $shortcut.Save()
}
Write-Output 'FREE_SHARE_LAUNCHERS_INSTALLED'
