import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "desktop_launcher"))
sys.path.insert(0, str(ROOT))
from free_share import share_sleep_app as share


class ShareLauncherTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name).resolve()
        self.app = share.ShareApp(self.root)
        self.app.directory.mkdir()
        self.url = "https://sleep-test-example.trycloudflare.com"
        self.tunnel = {"pid": 123456, "created": 100}
        self.server = {"pid": 123457, "created": 101}
        sockets = patch.object(share.socket, "socket")
        self.socket_factory = sockets.start()
        self.socket_factory.return_value.connect_ex.return_value = 1
        self.addCleanup(sockets.stop)

    def state(self):
        return {"project": str(self.root), "port": share.PORT, "url": self.url, "tunnel": self.tunnel, "server": self.server}

    def binary(self):
        content = b"FAKE TEST BINARY; NEVER EXECUTED"
        (self.app.directory / f"cloudflared-{share.VERSION}.exe").write_bytes(content)
        (self.root / "app.py").write_text("# fake app", encoding="utf-8")
        return hashlib.sha256(content).hexdigest()

    def test_public_address_validation(self):
        self.assertTrue(share.public_url(self.url))
        for url in ("http://example.trycloudflare.com", "https://trycloudflare.com", "https://a.trycloudflare.com.evil.test", self.url + "/path", self.url + ":443", "https://user@a.trycloudflare.com", None):
            self.assertFalse(share.public_url(url))

    def test_other_project_state_never_terminates_processes(self):
        state = self.state() | {"project": str(self.root / "other")}
        self.app.save(state)
        with patch.object(share, "terminate_owned") as terminate:
            self.app.stop()
            terminate.assert_not_called()

    def test_stop_closes_tunnel_before_server_and_removes_url(self):
        self.app.save(self.state())
        (self.app.directory / "url.txt").write_text(self.url)
        with patch.object(share, "terminate_owned") as terminate:
            self.app.stop()
        self.assertEqual([call.args[0] for call in terminate.call_args_list], [self.tunnel, self.server])
        self.assertFalse(self.app.state_path.exists())
        self.assertFalse((self.app.directory / "url.txt").exists())

    def test_wrong_signature_never_kills_a_reused_process_id(self):
        child = subprocess.Popen([sys._base_executable, "-c", "import time; time.sleep(30)"], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=subprocess.CREATE_NO_WINDOW)
        self.addCleanup(lambda: child.terminate() if child.poll() is None else None)
        created = share.process_signature(child.pid)
        self.assertIsNotNone(created)
        share.terminate_owned({"pid": child.pid, "created": created + 1})
        self.assertIsNone(child.poll())
        share.terminate_owned({"pid": child.pid, "created": created})
        child.wait(timeout=5)
        self.assertIsNotNone(child.returncode)

    def test_bad_binary_hash_is_rejected_without_execution(self):
        self.binary()
        with patch.object(self.app, "spawn") as spawn, self.assertRaisesRegex(RuntimeError, "검증된"):
            self.app.start()
        spawn.assert_not_called()

    def test_start_configures_public_host_limits_and_reuses_running_pair(self):
        def spawn(command, log_path, env=None):
            if log_path == self.app.tunnel_log:
                log_path.write_text("Created: " + self.url, encoding="utf-8")
                return self.tunnel
            return self.server
        with patch.object(share, "SHA256", self.binary()), patch.object(self.app, "spawn", side_effect=spawn) as start, patch.object(share, "alive", return_value=True), patch.object(share, "reachable", return_value=True):
            self.assertEqual(self.app.start(), self.url)
            command = start.call_args_list[1].args[0]
            env = start.call_args_list[1].args[2]
            self.assertIn("--server.enableXsrfProtection=true", command)
            self.assertIn("--browser.serverAddress=sleep-test-example.trycloudflare.com", command)
            self.assertEqual(env["COACHING_GLOBAL_LIMIT_24H"], "100")
            self.assertEqual(env["SLEEP_DB_PATH"], str(self.root / "data" / "sleep_records.sqlite3"))
            self.assertEqual(self.app.start(), self.url)
            self.assertEqual(start.call_count, 2)
        self.assertEqual(json.loads(self.app.state_path.read_text(encoding="utf-8"))["server"], self.server)

    def test_partial_start_failure_cleans_up_tunnel(self):
        def spawn(command, log_path, env=None):
            if log_path == self.app.tunnel_log:
                log_path.write_text(self.url, encoding="utf-8")
                return self.tunnel
            raise RuntimeError("fake server failed")
        with patch.object(share, "SHA256", self.binary()), patch.object(self.app, "spawn", side_effect=spawn), patch.object(share, "alive", return_value=True), patch.object(share, "terminate_owned") as terminate:
            with self.assertRaisesRegex(RuntimeError, "fake server failed"):
                self.app.start()
        terminate.assert_any_call(self.tunnel)
        self.assertFalse(self.app.state_path.exists())

    def test_dead_public_address_is_replaced_even_when_processes_are_alive(self):
        old_url = "https://old-dead-tunnel.trycloudflare.com"
        self.app.save(self.state() | {"url": old_url})
        def spawn(command, log_path, env=None):
            if log_path == self.app.tunnel_log:
                log_path.write_text(self.url, encoding="utf-8")
                return self.tunnel
            return self.server
        with patch.object(share, "SHA256", self.binary()), patch.object(self.app, "spawn", side_effect=spawn), patch.object(share, "alive", return_value=True), patch.object(share, "reachable", side_effect=lambda url, timeout=5: url != old_url), patch.object(share, "terminate_owned") as terminate:
            self.assertEqual(self.app.start(), self.url)
        terminate.assert_any_call(self.tunnel)
        self.assertEqual(self.app.load()["url"], self.url)


if __name__ == "__main__":
    unittest.main()
