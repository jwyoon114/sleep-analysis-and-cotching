"""Exercise the real Next.js cookie proxy and FastAPI using a disposable DB.

No real accounts, health records, API keys, or paid AI calls are used.
Run with the existing backend virtualenv's Python and pass the Node executable.
"""
import http.cookiejar
from contextlib import closing
import json
import os
from pathlib import Path
import socket
import sqlite3
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
from uuid import uuid4

ROOT = Path(__file__).resolve().parent
BACKEND = ROOT.parent / "mobile_backend"


def port():
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def main():
    node = Path(sys.argv[1]).resolve(strict=True)
    runtime = ROOT / ".runtime"
    runtime.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(dir=runtime) as directory:
        directory = Path(directory)
        backend_port, frontend_port = port(), port()
        env = os.environ.copy()
        env.update({"SLEEP_DB_PATH": str(directory / "test.sqlite3"), "PYTHONPATH": os.pathsep.join([str(BACKEND), str(Path(sys.prefix) / "Lib" / "site-packages")]),
                    "OPENAI_API_KEY": "", "PYTHONUTF8": "1", "NEXT_TELEMETRY_DISABLED": "1", "SLEEP_NEXT_DIST_DIR": ".next-test",
                    "SLEEP_API_URL": f"http://127.0.0.1:{backend_port}", "PATH": str(node.parent) + os.pathsep + env.get("PATH", "")})
        flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
        logs = [open(directory / name, "wb") for name in ("backend.log", "frontend.log")]
        processes = []
        try:
            processes.append(subprocess.Popen([getattr(sys,"_base_executable",sys.executable), "-B", "-m", "uvicorn", "api:app", "--host", "127.0.0.1", "--port", str(backend_port)], cwd=BACKEND, env=env, stdout=logs[0], stderr=subprocess.STDOUT, creationflags=flags))
            processes.append(subprocess.Popen([str(node), str(ROOT / "node_modules/next/dist/bin/next"), "dev", "--hostname", "127.0.0.1", "--port", str(frontend_port)], cwd=ROOT, env=env, stdout=logs[1], stderr=subprocess.STDOUT, creationflags=flags))
            base = f"http://127.0.0.1:{frontend_port}"
            plain = urllib.request.build_opener(urllib.request.ProxyHandler({}))
            deadline = time.monotonic() + 120
            while True:
                try:
                    with plain.open(base+"/api/sleep/health", timeout=20) as r:
                        if json.load(r).get("status") == "ok": break
                except (OSError, ValueError):
                    if time.monotonic() > deadline: raise RuntimeError("Test servers did not become ready.") from None
                    if any(p.poll() is not None for p in processes): raise RuntimeError("A test server stopped.")
                    time.sleep(.5)

            def client(): return urllib.request.build_opener(urllib.request.ProxyHandler({}), urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
            a,b=client(),client()
            def call(opener, endpoint, method="GET", body=None, expected=200, origin=None, raw=None, content_type=None):
                headers={"Origin": origin or base}
                data = raw if raw is not None else json.dumps(body).encode() if body is not None else None
                if data is not None: headers["Content-Type"] = content_type or "application/json"
                request=urllib.request.Request(base+"/api/sleep/"+endpoint,data=data,headers=headers,method=method)
                try: response=opener.open(request,timeout=40)
                except urllib.error.HTTPError as e: response=e
                with response:
                    assert response.status == expected, (endpoint,response.status,response.read(500).decode(errors="replace"))
                    result=json.load(response)
                    return result,response.headers

            call(a,"auth/me",expected=401)
            call(a,"auth/register","POST",{"username":"bad-origin","password":"test-password-123"},expected=403,origin="https://example.invalid")
            call(a,"auth/register","POST",{"username":"bad-origin","password":"test-password-123"},expected=403,origin="null")
            name="web-test-"+uuid4().hex[:10]
            owner,_=call(a,"auth/register","POST",{"username":name,"password":"test-password-123"},expected=201)
            call(b,"auth/register","POST",{"username":name+"-b","password":"test-password-123"},expected=201)
            result,headers=call(a,"auth/login","POST",{"username":name,"password":"test-password-123"})
            assert "token" not in result
            assert "httponly" in headers.get("set-cookie","").lower()
            assert "samesite=strict" in headers.get("set-cookie","").lower()
            assert "no-store" in headers.get("cache-control","")
            call(b,"auth/login","POST",{"username":name+"-b","password":"test-password-123"})
            print("COOKIE_LOGIN_AND_ORIGIN_CHECK_OK",flush=True)
            boundary="sleep-test-"+uuid4().hex
            fixture=(BACKEND/"examples/sleep_example.json").read_bytes()
            payload=(f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="example.json"\r\nContent-Type: application/json\r\n\r\n'.encode()+fixture+f'\r\n--{boundary}--\r\n'.encode())
            imported,_=call(a,"analyze","POST",raw=payload,content_type="multipart/form-data; boundary="+boundary)
            assert imported["added_sessions"]==1
            sid=imported["analysis_ids"][0]
            call(b,"watch/sessions/"+sid,expected=404)
            other,_=call(b,"watch/sessions")
            assert not other["sessions"]
            with closing(sqlite3.connect(directory/"test.sqlite3")) as db, db:
                db.execute("INSERT INTO coaching VALUES(?,?,?,?,?,?)",("test-coach",owner["user"]["id"],sid,"가상 검증 코칭","{}","2026-11-06T00:00:00+00:00"))
            history,_=call(a,f"watch/sessions/{sid}/coaching")
            assert history["history"][0]["coaching"]=="가상 검증 코칭"
            call(a,f"watch/sessions/{sid}/coaching/test-coach","DELETE")
            call(a,"watch/trash/coaching/test-coach/restore","POST")
            call(a,f"watch/sessions/{sid}","DELETE")
            call(a,f"watch/sessions/{sid}",expected=404)
            call(a,f"watch/trash/session/{sid}/restore","POST")
            call(a,f"watch/sessions/{sid}")
            comparison,_=call(a,"watch/comparison?days=7&end_date=2026-11-06")
            assert comparison["current"]["session_count"]==1
            call(a,f"watch/sessions/{sid}","DELETE")
            call(a,f"watch/trash/session/{sid}","DELETE")
            records,_=call(a,"watch/sessions")
            assert not records["sessions"]
            print("IMPORT_HISTORY_RESTORE_PURGE_AND_ISOLATION_OK",flush=True)
            call(a,"auth/me","PATCH",{"current_password":"test-password-123","new_username":name+"-new"})
            call(a,"auth/me",expected=401)
            call(a,"auth/login","POST",{"username":name+"-new","password":"test-password-123"})
            call(a,"auth/me","DELETE",{"current_password":"test-password-123","confirmation":"계정 삭제"})
            call(a,"auth/me",expected=401)
            call(b,"auth/me")
            call(b,"auth/logout","POST")
            call(b,"auth/me",expected=401)
            call(a,"not-an-endpoint",expected=404)
            print("ACCOUNT_EDIT_DELETE_AND_LOGOUT_OK",flush=True)
            print("FRONTEND_INTEGRATION_OK_NO_REAL_DATA_OR_AI_CALLS",flush=True)
        finally:
            for process in reversed(processes):
                if process.poll() is None:
                    if os.name == "nt": subprocess.run(["taskkill","/PID",str(process.pid),"/T","/F"],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=flags)
                    else: process.terminate()
                    process.wait(timeout=15)
            for log in logs: log.close()


if __name__=="__main__":main()
