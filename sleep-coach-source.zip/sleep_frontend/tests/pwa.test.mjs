import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';

test('offline worker caches only its public notice and never intercepts account API requests',async()=>{
  const events={},added=[];
  let online=true;
  const context={URL,Response,self:{location:{origin:'https://app.example'},addEventListener:(kind,handler)=>events[kind]=handler,skipWaiting:()=>{},clients:{claim:async()=>{}}},caches:{open:async()=>({add:async url=>added.push(url)}),keys:async()=>[],match:async()=>new Response('offline notice')},fetch:async()=>{if(!online)throw Error('offline');return new Response('private live page');}};
  vm.runInNewContext(await readFile(new URL('../public/sw.js',import.meta.url),'utf8'),context);
  let install;
  events.install({waitUntil:p=>install=p});await install;
  assert.deepEqual(added,['/offline.html']);
  let apiIntercepted=false;
  events.fetch({request:{mode:'cors',method:'GET',url:'https://app.example/api/sleep/watch/sessions'},respondWith:()=>apiIntercepted=true});
  assert.equal(apiIntercepted,false);
  let response;
  const navigation={request:{mode:'navigate',method:'GET',url:'https://app.example/'},respondWith:p=>response=p};
  events.fetch(navigation);assert.equal(await (await response).text(),'private live page');
  online=false;
  events.fetch(navigation);assert.equal(await (await response).text(),'offline notice');
  assert.deepEqual(added,['/offline.html']);
});
