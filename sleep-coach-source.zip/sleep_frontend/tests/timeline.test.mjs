import test from 'node:test';
import assert from 'node:assert/strict';
import {buildTimeline,segmentAt} from '../src/lib/timeline.ts';

const segment=(start,end,stage='core')=>({start,end,stage,minutes:0});
test('midnight crossing uses elapsed time and preserves original clocks',()=>{
  const timeline=buildTimeline({start:'2026-11-06T23:00:00+09:00',end:'2026-11-07T01:00:00+09:00',segments:[segment('2026-11-06T23:00:00+09:00','2026-11-07T00:00:00+09:00'),segment('2026-11-07T00:00:00+09:00','2026-11-07T01:00:00+09:00','deep')]});
  assert.equal(timeline.duration,2*3600000);assert.equal(timeline.gaps.length,0);
  assert.equal(segmentAt(timeline.segments,Date.parse('2026-11-07T00:00:00+09:00')),1);
  assert.equal(segmentAt(timeline.segments,timeline.end),-1);
});
test('unrecorded periods stay gaps rather than becoming a sleep stage',()=>{
  const timeline=buildTimeline({start:'2026-11-06T20:00:00+09:00',end:'2026-11-07T02:00:00+09:00',segments:[segment('2026-11-07T00:00:00+09:00','2026-11-07T01:00:00+09:00','unspecified'),segment('2026-11-06T21:00:00+09:00','2026-11-06T23:00:00+09:00','deep')]});
  assert.equal(timeline.gaps.length,3);assert.equal(timeline.segments[1].stage,'unspecified');
  assert.equal(segmentAt(timeline.segments,Date.parse('2026-11-06T23:30:00+09:00')),-1);
});
test('daylight-saving clock repetition is plotted using actual offsets',()=>{
  const timeline=buildTimeline({start:'2026-11-01T00:30:00-04:00',end:'2026-11-01T02:30:00-05:00',segments:[segment('2026-11-01T00:30:00-04:00','2026-11-01T02:30:00-05:00')]});
  assert.equal(timeline.duration,3*3600000);
});
test('invalid bounds and empty records do not fabricate stages',()=>{
  assert.equal(buildTimeline({start:'bad',end:'bad',segments:[]}),null);
  const timeline=buildTimeline({start:'2026-11-06T20:00:00Z',end:'2026-11-06T21:00:00Z',segments:[]});
  assert.equal(timeline.segments.length,0);assert.equal(timeline.gaps.length,1);
});
