# 달잠 · Next.js 수면 리포트

기존 Python 수면 앱의 계정·분석·코칭 API를 사용하는 새 웹 프론트엔드입니다.
Next.js 16 App Router, React, TypeScript, 반응형 CSS로 구현했습니다.

## 포함된 화면

- 로그인·회원가입, 실제 데이터를 저장하지 않는 가상 체험 모드
- 대시보드: 최근 기록, 수면량, 지난밤 시간별 수면 단계 그래프, 최근 7일 흐름, 저장된 코칭
- 분석 기록: 검색·선택, 단계별 시간, 전체 구간, 생체지표, JSON 다운로드
- 시간별 수면 양상: 원본 시각에 따른 단계 변화 그래프, 구간 선택·터치·키보드 탐색, 미기록 빗금 표시
- AI 코칭: 생활습관 입력, 새 코칭 생성, 저장된 코칭·생성 근거 조회 및 삭제
- 7일·30일 비교: 기준일 변경, 미기록 날짜 공백, 기록일 평균
- 휴지통: 복원·영구 삭제 확인, 백업 정리 상태
- 계정: 아이디·비밀번호 변경, 확인 문구·비밀번호를 통한 계정 삭제

## 로컬 실행

Node.js를 설치하고 이 폴더에서 `npm install`을 실행합니다. Python API도 함께 실행해야 합니다.

```powershell
# 기존 Python 앱 폴더에서 실행. 기존 .venv와 DB를 사용합니다.
.\.venv\Scripts\python.exe -m uvicorn api:app --host 127.0.0.1 --port 8011
```

```powershell
# sleep_frontend 폴더에서 실행
npm run dev
```

- 웹 화면: http://127.0.0.1:3000
- 가상 기록 체험: http://127.0.0.1:3000/?demo=1
- 서버 API 주소는 서버 전용 환경변수 `SLEEP_API_URL`로 지정합니다. 기본값은 `http://127.0.0.1:8011`입니다.
- 새 PC에서는 Python 서버를 별도로 설치해야 합니다. 기존 계정·수면 DB와 API 키는 소스에 포함하지 않습니다.
- 코칭 API 키는 기존 Python 서버에서 읽습니다. 프론트엔드에 API 키를 넣지 않습니다.

## 바탕화면 실행

다른 Windows PC에 새로 설치하려면 [배포 안내](../windows_distribution/README.md)를 참고하세요.
`windows_distribution/build_package.py`가 현재 웹 화면과 서버, 초기 설치 도구를 묶은 ZIP을 만듭니다.
기존 PC의 바로가기를 복사하는 대신, 받는 PC에서 `SETUP.cmd`로 전용 바로가기를 만듭니다.

처음 한 번 `npm run build`로 빌드한 뒤 다음과 같이 바로가기를 설치합니다.

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install-desktop.ps1 -BackendProjectPath '기존 Python 앱 폴더의 전체 경로'
```

**달잠 웹앱 실행** 아이콘을 누르면 API와 웹 서버를 시작하고 브라우저를 엽니다.
**달잠 웹앱 종료**는 이 실행기가 시작한 프로세스만 종료합니다. 이미 별도로 실행 중인 API는 유지합니다.
개발 미리보기 서버가 3000번 포트를 사용 중이면 먼저 해당 미리보기를 종료하세요.
코드를 바꾼 뒤에는 종료하고 `npm run build` 후 다시 실행합니다.

## 인증 및 데이터

## 취침·기상 PC 알람

AI 수면 코칭 화면에서 AI 제안 시간을 불러오거나 직접 시간을 정하고 매일 반복 알람을 저장합니다.
기능 추가 전에 생성한 코칭에는 제안 시간이 없으므로 새 코칭을 생성하거나 직접 입력합니다.
Windows PC와 Python 서버가 실행 중이면 브라우저를 닫거나 로그아웃해도 소리와 창으로 알립니다.
PC 종료·절전·서버 종료 시에는 울리지 않으며, 휴대폰에는 알람이 설정되지 않습니다.
계정마다 알람 설정이 저장되며 계정 삭제 시 함께 삭제됩니다. 소리는 최대 1분 재생됩니다.
원격·클라우드 서버에서는 `SLEEP_DESKTOP_ALARMS=0`으로 PC 알람을 비활성화하세요.

브라우저는 같은 출처의 `/api/sleep/*` 경로에 요청합니다. Next.js 서버가 Python API에 요청을 전달합니다.
로그인 토큰은 HttpOnly·SameSite=Strict 쿠키에 보관하고 브라우저 저장소나 로그인 JSON 응답으로 노출하지 않습니다.
HTTPS 또는 Vercel에서는 Secure 속성을 적용합니다. 변경 요청은 Origin을 검사합니다.
기록과 코칭 응답은 캐시하지 않으며, 계정 구분은 기존 Python 서버에서 검사합니다.

파일은 최대 4MiB입니다. 분석·저장만으로 AI 요청이 발생하지 않습니다.
AI 생성 버튼을 누를 때 외부 호출과 사용료가 발생합니다. 가상 체험 모드는 API 요청을 보내지 않습니다.

## Vercel 배포 준비

Vercel 프로젝트의 Root Directory를 `sleep_frontend`, Framework Preset을 Next.js로 지정할 수 있습니다.
Build Command는 `npm run build`입니다.
**실제 로그인·분석을 사용하려면 Vercel에서 접근할 수 있는 Python API의 HTTPS 주소가 필요합니다.**
Vercel의 `SLEEP_API_URL`에 그 주소를 설정해야 합니다. Vercel에서 `127.0.0.1`은 사용자 PC가 아닙니다.
현재 PC용 Streamlit 공유 주소는 이 API 주소로 사용할 수 없습니다.
기존 SQLite DB를 Vercel 함수에 복사하지 마세요. 이 구현은 Vercel 배포나 유료 자원을 자동 생성하지 않습니다.

## 검증

```powershell
npm run typecheck
npm run build
# 기존 backend 가상환경의 Python으로 실행하며 Node 실행 경로를 전달합니다.
python .\verify_integration.py 'node.exe의 전체 경로'
```

통합 검증은 임시 DB와 별도 포트를 사용합니다. 실제 건강 정보나 유료 AI 호출 없이
로그인 쿠키, 출처 검사, 계정 분리, 업로드, 코칭 조회, 복원·삭제 및 계정 변경을 확인합니다.
