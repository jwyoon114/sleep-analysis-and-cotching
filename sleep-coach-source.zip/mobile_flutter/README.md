# 나의 수면 리포트 · Flutter 모바일 화면

회원가입/로그인 → 수면 .md 또는 .json 업로드 → 기록 분석 → OpenAI 코칭의 흐름입니다.
EEG 모델과 EDF 업로드 화면을 제거하고 `mobile_backend`의 인증 API에 연결했습니다.
자신의 계정 기록과 저장된 조언을 다시 불러올 수 있습니다.

Flutter SDK가 설치되어 있다면 이 폴더의 `create-project.ps1`을 실행합니다.
새 `sleep_mobile` Android 프로젝트를 만들고 소스를 복사한 뒤 의존성 설치, 포맷,
정적 분석, 위젯 테스트를 수행합니다. 이미 같은 이름의 폴더가 있으면 덮어쓰지 않습니다.

```powershell
.\create-project.ps1
cd ..\sleep_mobile
flutter run
```

서버는 별도로 실행해야 합니다. Android 에뮬레이터의 서버 주소는
`http://10.0.2.2:8000`, 실제 휴대폰은 같은 Wi-Fi PC의 내부 IP를 사용합니다.
실제 휴대폰에 연결할 때 Python 서버는 `--host 0.0.0.0`으로 실행합니다.

OpenAI API 키는 서버에만 둡니다. 로그인 토큰은 앱 메모리에 보관하므로 앱을 완전히
다시 시작하면 로그인해야 합니다. 로그아웃 시 서버 토큰도 폐기합니다.
지원 형식은 Health Data Export Markdown(.md) 및 수면 JSON v1(.json)입니다. JSON 구조는
`mobile_backend/JSON_FORMAT.md`를 참고하세요. Apple 건강 XML은 지원하지 않습니다.

현재 PC에서 Flutter SDK를 찾을 수 없어 Android 빌드·위젯 테스트 실행은 완료하지 못했습니다.
Python API와 웹앱의 인증·파일 분석 흐름은 별도의 통합 테스트로 검증합니다.
