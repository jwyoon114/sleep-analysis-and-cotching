import 'dart:async';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'sleep_api.dart';

void main() => runApp(const SleepApp());

class SleepApp extends StatelessWidget {
  const SleepApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: '나의 수면 리포트',
    theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF38558C)), scaffoldBackgroundColor: const Color(0xFFF4F6FC)),
    home: const SleepScreen(),
  );
}

class SleepScreen extends StatefulWidget {
  const SleepScreen({super.key});
  @override
  State<SleepScreen> createState() => _SleepScreenState();
}

class _SleepScreenState extends State<SleepScreen> {
  final address = TextEditingController(text: 'http://10.0.2.2:8000');
  final username = TextEditingController();
  final password = TextEditingController();
  String? token;
  String? displayName;
  String? error;
  String? notice;
  String? advice;
  bool busy = false;
  bool signingUp = false;
  PlatformFile? file;
  List<Map<String, dynamic>> sessions = [];
  Map<String, dynamic>? summary;
  String? selectedId;
  String age = '미입력', caffeine = '미입력', regularity = '미입력', satisfaction = '미입력';
  SleepApi get api => SleepApi(address.text, token: token);
  Map<String, dynamic>? get current {
    for (final s in sessions) { if (s['analysis_id'] == selectedId) return s; }
    return null;
  }
  @override
  void dispose() { address.dispose(); username.dispose(); password.dispose(); super.dispose(); }

  Future<void> perform(Future<void> Function() action) async {
    setState(() { busy = true; error = null; notice = null; });
    try { await action(); }
    on TimeoutException { if (mounted) setState(() => error = '응답 시간이 초과됐습니다. 서버를 확인하세요.'); }
    on SocketException { if (mounted) setState(() => error = '서버에 연결할 수 없습니다. 서버 주소와 Wi-Fi를 확인하세요.'); }
    catch (e) { if (mounted) setState(() => error = e.toString().replaceFirst('Exception: ', '')); }
    finally { if (mounted) setState(() => busy = false); }
  }

  Future<void> loadHistory() async {
    final data = await api.get('/watch/sessions');
    final rows = (data['sessions'] as List).map((s) => Map<String, dynamic>.from(s as Map)).toList();
    if (!mounted) return;
    setState(() {
      sessions = rows; summary = Map<String, dynamic>.from(data['overview'] as Map);
      if (!rows.any((s) => s['analysis_id'] == selectedId)) selectedId = rows.isEmpty ? null : rows.first['analysis_id'] as String;
      advice = null;
    });
    await loadAdvice();
  }

  Future<void> loadAdvice() async {
    if (selectedId == null) return;
    final data = await api.get('/watch/sessions/$selectedId/coaching');
    if (mounted) setState(() => advice = (data['result'] as Map?)?['coaching'] as String?);
  }

  Future<void> authenticate() => perform(() async {
    if (signingUp) {
      await api.post('/auth/register', {'username': username.text.trim(), 'password': password.text});
      if (mounted) setState(() { signingUp = false; notice = '회원가입 완료. 로그인하세요.'; });
      return;
    }
    final data = await api.post('/auth/login', {'username': username.text.trim(), 'password': password.text});
    if (!mounted) return;
    setState(() { token = data['token'] as String; displayName = (data['user'] as Map)['username'] as String; password.clear(); });
    await loadHistory();
  });

  Future<void> pick() => perform(() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.any, allowMultiple: false);
    if (result == null || !mounted) return;
    final selected = result.files.single;
    if ((!selected.name.toLowerCase().endsWith('.md') && !selected.name.toLowerCase().endsWith('.json')) || selected.path == null) throw const FormatException('기기에 저장한 수면 .md 또는 .json 파일을 선택하세요.');
    if (selected.size > 10 * 1024 * 1024) throw const FormatException('10MiB 이하 파일을 선택하세요.');
    setState(() => file = selected);
  });

  Future<void> importFile() => perform(() async {
    final selected = file;
    if (selected?.path == null) return;
    final data = await api.importFile(selected!.path!, selected.name);
    await loadHistory();
    if (mounted) setState(() => notice = data['added_sessions'] == 0 ? '이미 저장된 기록입니다.' : '새 기록 ${data['added_sessions']}건을 저장했습니다.');
  });

  Future<void> coach() => perform(() async {
    final data = await api.post('/coach', {'analysis_id': selectedId, 'age_group': age, 'caffeine': caffeine, 'regularity': regularity, 'satisfaction': satisfaction});
    if (mounted) setState(() => advice = data['coaching'] as String);
  });

  String duration(Object? value) {
    final m = (value as num).round();
    return '${m ~/ 60}시간 ${m % 60}분';
  }
  String clock(Object? value) => value.toString().substring(0, 19).replaceFirst('T', ' ');
  static const labels = {'core': '코어 수면', 'deep': '깊은 수면', 'rem': '렘수면', 'wake': '각성', 'unspecified': '수면(미분류)'};
  Widget card(String title, List<Widget> children) => Card(child: Padding(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), const SizedBox(height: 12), ...children])));
  Widget choice(String title, String value, List<String> options, ValueChanged<String> update) => Padding(padding: const EdgeInsets.only(bottom: 12), child: DropdownButtonFormField<String>(initialValue: value, decoration: InputDecoration(labelText: title), items: options.map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: busy ? null : (v) { if (v != null) setState(() => update(v)); }));

  @override
  Widget build(BuildContext context) {
    final s = current;
    return Scaffold(
      appBar: AppBar(title: const Text('나의 수면 리포트'), actions: [if (token != null) TextButton(onPressed: busy ? null : () => perform(() async {
        await api.post('/auth/logout', {});
        if (mounted) setState(() { token = null; displayName = null; sessions = []; summary = null; selectedId = null; advice = null; file = null; });
      }), child: const Text('로그아웃'))]),
      body: SafeArea(child: SingleChildScrollView(padding: const EdgeInsets.all(16), child: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 720), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        if (busy) const LinearProgressIndicator(),
        if (error != null) Padding(padding: const EdgeInsets.all(12), child: Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error))),
        if (notice != null) Padding(padding: const EdgeInsets.all(12), child: Text(notice!)),
        if (token == null) ...[
          card('수면 기록으로 시작하세요', [
            const Text('수면 .md 또는 .json 파일을 분석하고 나에게 맞는 AI 조언을 받아보세요.'),
            const SizedBox(height: 16),
            TextField(controller: address, enabled: !busy, decoration: const InputDecoration(labelText: '서버 주소')),
            const Text('Android 가상 기기: http://10.0.2.2:8000\n실제 휴대폰: PC의 내부 IP 주소', style: TextStyle(fontSize: 12)),
            TextField(controller: username, enabled: !busy, decoration: const InputDecoration(labelText: '아이디')),
            TextField(controller: password, enabled: !busy, obscureText: true, decoration: const InputDecoration(labelText: '비밀번호 · 10자 이상')),
            const SizedBox(height: 16),
            FilledButton(onPressed: busy ? null : authenticate, child: Text(signingUp ? '회원가입' : '로그인')),
            TextButton(onPressed: busy ? null : () => setState(() { signingUp = !signingUp; error = null; }), child: Text(signingUp ? '이미 계정이 있어요 · 로그인' : '처음이신가요? 회원가입')),
          ]),
        ] else ...[
          Text('$displayName 님의 수면 기록', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          card('1. 파일 가져오기', [
            const Text('Health Data Export .md, Health Export Kit JSON v2 또는 수면 JSON v1 파일을 선택하세요. Apple 건강 XML은 지원하지 않습니다.'),
            OutlinedButton.icon(onPressed: busy ? null : pick, icon: const Icon(Icons.upload_file), label: const Text('수면 파일 선택')),
            if (file != null) Text(file!.name),
            FilledButton(onPressed: busy || file == null ? null : importFile, child: const Text('분석하고 내 기록에 저장')),
            TextButton(onPressed: busy ? null : () => perform(loadHistory), child: const Text('저장된 기록 새로고침')),
          ]),
          if (sessions.isEmpty) const Padding(padding: EdgeInsets.all(16), child: Text('아직 내 기록이 없습니다. 파일을 올려보세요.')),
          if (summary != null && sessions.isNotEmpty) card('2. 기간별 수면 패턴', [
            Text('기록 ${summary!['session_count']}회 · 기록일 ${summary!['recorded_days']}일'),
            Text('기록일당 수면 합계 평균: ${duration(summary!['average_asleep_minutes_per_recorded_day'])}'),
            const Text('수면 시작일 기준입니다. 기록 없는 날은 평균에서 제외합니다. 하루 전체 수면량을 측정했다고 가정하지 않습니다.', style: TextStyle(fontSize: 12)),
            DropdownButton<String>(isExpanded: true, value: selectedId, items: sessions.map((row) => DropdownMenuItem(value: row['analysis_id'] as String, child: Text(clock(row['start'])))).toList(), onChanged: busy ? null : (v) { if (v != null) { setState(() { selectedId = v; advice = null; }); perform(loadAdvice); } }),
          ]),
          if (s != null) ...[
            card('3. 선택한 수면 기록', [
              Text('${clock(s['start'])}\n~ ${clock(s['end'])} (${s['timezone']})'),
              const SizedBox(height: 12),
              Text('기기 추정 수면: ${duration(s['asleep_minutes'])}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              Text('각성: ${duration(s['awake_minutes'])} · 각성 구간 ${s['wake_segment_count']}회'),
              if ((s['unrecorded_minutes'] as num) > 0) Text('미기록 구간: ${duration(s['unrecorded_minutes'])}'),
              const Text('웨어러블 기기의 추정 기록이며 진단 결과가 아닙니다.', style: TextStyle(fontSize: 12)),
              for (final stage in (s['stage_minutes'] as Map).entries) Text('${labels[stage.key] ?? stage.key}: ${duration(stage.value)}'),
              ExpansionTile(title: const Text('수면·각성 시각 전체 보기'), children: [for (final segment in s['segments'] as List) ListTile(dense: true, title: Text('${labels[segment['stage']]} · ${(segment['minutes'] as num).toStringAsFixed(1)}분'), subtitle: Text('${clock(segment['start'])} ~ ${clock(segment['end'])}'))]),
              ExpansionTile(title: const Text('생체지표 요약'), children: [for (final vital in s['vitals_summary'] as List) ListTile(title: Text('${vital['metric']} · 평균 ${vital['avg']} ${vital['unit']}'), subtitle: Text('표본 ${vital['n']}개 · 최소 ${vital['min']} · 최대 ${vital['max']}'))]),
            ]),
            card('4. 나에게 맞는 AI 코칭', [
              choice('연령 구분', age, ['미입력', '성인', '미성년자'], (v) => age = v),
              choice('취침 전 6시간 이내 카페인', caffeine, ['미입력', '없음', '있음'], (v) => caffeine = v),
              choice('취침·기상 시간', regularity, ['미입력', '대체로 일정함', '자주 달라짐'], (v) => regularity = v),
              choice('수면 만족도', satisfaction, ['미입력', '좋음', '보통', '나쁨'], (v) => satisfaction = v),
              const Text('선택 기록과 최근 최대 14회 기록의 요약 및 입력값을 OpenAI에 전송합니다. API 사용료가 발생할 수 있습니다.', style: TextStyle(fontSize: 12)),
              FilledButton(onPressed: busy ? null : coach, child: const Text('AI 조언 생성')),
              if (advice != null) SelectableText(advice!),
            ]),
          ],
        ],
      ]))))),
    );
  }
}
