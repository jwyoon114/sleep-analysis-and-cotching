import 'dart:convert';
import 'package:http/http.dart' as http;

class SleepApi {
  SleepApi(String address, {this.token}) {
    final parsed = Uri.tryParse(address.trim());
    if (parsed == null || !['http', 'https'].contains(parsed.scheme) ||
        parsed.host.isEmpty || parsed.hasQuery || parsed.hasFragment ||
        parsed.userInfo.isNotEmpty || (parsed.path.isNotEmpty && parsed.path != '/')) {
      throw const FormatException('서버 주소는 http://10.0.2.2:8000 형식으로 입력하세요.');
    }
    base = parsed;
  }
  late final Uri base;
  final String? token;
  Map<String, String> get headers => {
    if (token != null) 'Authorization': 'Bearer $token',
  };

  Map<String, dynamic> decode(http.Response response) {
    final Object? body;
    try { body = jsonDecode(utf8.decode(response.bodyBytes)); }
    on FormatException { throw const FormatException('서버 응답 형식과 주소를 확인하세요.'); }
    if (response.statusCode < 200 || response.statusCode >= 300) {
      final detail = body is Map ? body['detail'] : null;
      if (detail is Map) throw Exception(detail['message'] ?? '요청을 처리하지 못했습니다.');
      if (detail is String) throw Exception(detail);
      throw Exception('입력값을 확인하세요. 오류 코드: ${response.statusCode}');
    }
    if (body is! Map) throw const FormatException('서버 응답 형식이 다릅니다.');
    return Map<String, dynamic>.from(body);
  }

  Future<Map<String, dynamic>> get(String path) async {
    final client = http.Client();
    try {
      return decode(await client.get(base.replace(path: path), headers: headers).timeout(const Duration(seconds: 20)));
    } finally { client.close(); }
  }

  Future<Map<String, dynamic>> post(String path, Map<String, dynamic> payload) async {
    final client = http.Client();
    try {
      return decode(await client.post(base.replace(path: path), headers: {...headers, 'Content-Type': 'application/json'}, body: jsonEncode(payload)).timeout(const Duration(seconds: 70)));
    } finally { client.close(); }
  }

  Future<Map<String, dynamic>> importFile(String path, String filename) async {
    final client = http.Client();
    try {
      final request = http.MultipartRequest('POST', base.replace(path: '/watch/import'));
      request.headers.addAll(headers);
      request.files.add(await http.MultipartFile.fromPath('file', path, filename: filename));
      return decode(await (() async => http.Response.fromStream(await client.send(request)))().timeout(const Duration(seconds: 60)));
    } finally { client.close(); }
  }
}
