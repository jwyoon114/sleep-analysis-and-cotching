import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sleep_mobile/main.dart';

void main() {
  testWidgets('Login is required before accessing sleep records and coaching', (tester) async {
    await tester.pumpWidget(const SleepApp());
    expect(find.text('나의 수면 리포트'), findsOneWidget);
    expect(find.text('AI 조언 생성'), findsNothing);
    expect(find.text('분석하고 내 기록에 저장'), findsNothing);
    expect(find.widgetWithText(FilledButton, '로그인'), findsOneWidget);
  });
}
