$ErrorActionPreference = 'Stop'

if (-not (Get-Command flutter -ErrorAction SilentlyContinue)) {
    throw 'Flutter SDK is not on PATH. Install Flutter, restart the terminal, and run flutter doctor.'
}

$destination = Join-Path (Split-Path -Parent $PSScriptRoot) 'sleep_mobile'
if (Test-Path -LiteralPath $destination) {
    throw "Destination already exists; nothing was overwritten: $destination"
}

& flutter create --platforms=android --project-name=sleep_mobile $destination
if ($LASTEXITCODE -ne 0) { throw 'flutter create failed.' }

$files = @(
    'pubspec.yaml',
    'analysis_options.yaml',
    'lib/main.dart',
    'lib/sleep_api.dart',
    'test/widget_test.dart',
    'android/app/src/debug/AndroidManifest.xml'
)
foreach ($relative in $files) {
    $source = Join-Path $PSScriptRoot $relative
    $target = Join-Path $destination $relative
    New-Item -ItemType Directory -Path (Split-Path -Parent $target) -Force | Out-Null
    Copy-Item -LiteralPath $source -Destination $target -Force
}

Push-Location -LiteralPath $destination
try {
    & flutter pub get
    if ($LASTEXITCODE -ne 0) { throw 'flutter pub get failed.' }
    & dart format lib test
    if ($LASTEXITCODE -ne 0) { throw 'dart format failed.' }
    & flutter analyze
    if ($LASTEXITCODE -ne 0) { throw 'flutter analyze reported issues; inspect its output.' }
    & flutter test
    if ($LASTEXITCODE -ne 0) { throw 'flutter test failed.' }
    Write-Host "Project ready: $destination"
    Write-Host 'Start an Android emulator, then run flutter run from that folder.'
}
finally {
    Pop-Location
}
