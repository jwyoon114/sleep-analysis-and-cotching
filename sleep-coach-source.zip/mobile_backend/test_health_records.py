import json
from contextlib import closing
from pathlib import Path
import sqlite3
import tempfile
import unittest

from health_records import import_export, list_sessions, parse_export

FIXTURE = """# Health Data Export
- range: 2026-12-31 19:07 → 2027-01-02 19:07
- timezone: Asia/Seoul
## Session 1 — 12-31 23:59:00 → 01-01 00:02:00 (0h 03m)
- source: Test Watch
### Stages (3 segments)
```csv
time,stage,durationMin
12-31 23:59:00,core,1.0
01-01 00:00:00,wake,1.0
01-01 00:01:00,unspecified,1.0
```
"""


class HealthRecordsTest(unittest.TestCase):
    def test_new_year_timezone_and_unspecified(self):
        session = parse_export(FIXTURE.replace("\n", "\r\n"))["sessions"][0]
        self.assertEqual(session["end"], "2027-01-01T00:02:00+09:00")
        self.assertEqual(session["asleep_minutes"], 2)
        self.assertEqual(session["stage_minutes"]["unspecified"], 1)
        self.assertNotIn("N2", session["stage_minutes"])

    def test_dedup_persistence_and_subject_separation(self):
        with tempfile.TemporaryDirectory() as tmp:
            db = Path(tmp) / "records.sqlite3"
            self.assertEqual(import_export(FIXTURE, "a.md", db_path=db)["added_sessions"], 1)
            self.assertTrue(import_export(FIXTURE, "a.md", db_path=db)["duplicate_file"])
            self.assertEqual(len(list_sessions(db_path=db)), 1)
            self.assertEqual(import_export(FIXTURE, "a.md", subject="another", db_path=db)["added_sessions"], 1)
            with closing(sqlite3.connect(db)) as connection:
                self.assertEqual(connection.execute("SELECT count(*) FROM stages").fetchone()[0], 6)

    def test_conflicting_import_rolls_back(self):
        with tempfile.TemporaryDirectory() as tmp:
            db = Path(tmp) / "records.sqlite3"
            import_export(FIXTURE, "a.md", db_path=db)
            with self.assertRaises(ValueError):
                import_export(FIXTURE.replace(",core,", ",deep,"), "b.md", db_path=db)
            with closing(sqlite3.connect(db)) as connection:
                self.assertEqual(connection.execute("SELECT count(*) FROM imports").fetchone()[0], 1)

    def test_gap_is_not_counted_as_sleep(self):
        session = parse_export(FIXTURE.replace(",core,1.0", ",core,0.5"))["sessions"][0]
        self.assertEqual(session["unrecorded_minutes"], 0.5)
        self.assertEqual(session["asleep_minutes"], 1.5)
        self.assertTrue(session["warnings"])

    def test_overlap_and_invalid_values_rejected(self):
        for text in [FIXTURE.replace(",core,1.0", ",core,2.0"), FIXTURE.replace(",core,1.0", ",core,nan"), FIXTURE.replace(",core,", ",N2,")]:
            with self.assertRaises(ValueError):
                parse_export(text)


if __name__ == "__main__":
    unittest.main()
