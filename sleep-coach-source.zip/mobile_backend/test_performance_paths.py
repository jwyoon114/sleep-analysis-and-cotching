"""Regression checks for efficient reads without caching authentication or health data."""
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path
import sqlite3
import tempfile
import unittest

from health_records import connect
from history_service import expire_trash


class PerformancePathsTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / "test.sqlite3"

    def test_existing_database_is_migrated_once_and_recreated_if_removed(self):
        with closing(sqlite3.connect(self.path)) as db, db:
            db.execute("CREATE TABLE sessions(id TEXT PRIMARY KEY, subject TEXT NOT NULL, start TEXT NOT NULL, end TEXT NOT NULL, payload TEXT NOT NULL)")
            db.execute("INSERT INTO sessions VALUES('existing','owner','start','end','{}')")
        with closing(connect(self.path)) as db:
            self.assertEqual(db.execute("SELECT count(*) FROM sessions").fetchone()[0], 1)
            self.assertGreaterEqual(db.execute("PRAGMA user_version").fetchone()[0], 1)
            schema = db.execute("PRAGMA schema_version").fetchone()[0]
        with closing(connect(self.path)) as db:
            self.assertEqual(db.execute("PRAGMA schema_version").fetchone()[0], schema)
        self.path.unlink()
        with closing(connect(self.path)) as db:
            self.assertEqual(db.execute("SELECT count(*) FROM accounts").fetchone()[0], 0)

    def test_trash_check_does_not_decode_unexpired_record_payload(self):
        with closing(connect(self.path)) as db, db:
            db.execute("INSERT INTO sessions VALUES('a','owner','start','end','not-json')")
            db.execute("INSERT INTO trash_sessions VALUES('a','owner','2099-01-01T00:00:00+00:00')")
        self.assertEqual(expire_trash("owner", self.path, datetime(2026, 11, 6, tzinfo=timezone.utc)), 0)
        self.assertEqual(expire_trash("someone-else", self.path), 0)


if __name__ == "__main__":
    unittest.main()
