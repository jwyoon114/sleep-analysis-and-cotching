# 수면 JSON v1

## Health Export Kit 원본 JSON도 지원

`meta.schemaVersion: 2`, `meta.timeZone`, `meta.rangeStart/rangeEnd`,
`sleep.sessions`, `sleep.streams`를 포함한 Health Export Kit JSON은 변환 없이 업로드할 수 있습니다.
`asleepCore/asleepDeep/asleepREM/awake/asleepUnspecified` 단계를 내부 단계로 변환합니다.
생체지표의 `vitals` 및 `tupleSchema/sources/sourceIdx` 기반 전체 표본 스트림도 읽습니다.
집계 bin 스트림은 아직 지원하지 않으며, verbose(전체 표본) 내보내기가 필요합니다.

시각이 `HH:mm:ss`뿐이면 현지 날짜 범위와 겹치는 유일한 세션 날짜를 선택합니다.
자정을 넘는 수면과 내보내기 시작일 전날에 시작한 수면을 지원합니다. 여러 날짜 중
하나를 확정할 수 없는 파일은 추측하지 않고 날짜가 포함된 내보내기를 요청합니다.
기존 `MM-dd HH:mm:ss` MD 내보내기와 수면 JSON v1 지원은 유지합니다.

실제 제공된 2026-11-05 MD/JSON 쌍에는 생체지표 단계 평균에 0.1 차이의 반올림
차이가 있습니다. 출처·시각·수면 단계·표본 수가 일치하고 요약 값 차이가 0.1 이내일
때 같은 기록으로 인정하며 먼저 저장된 요약을 유지합니다. 원시 표본은 별도로 중복 제거합니다.
HRV SDNN의 원시 표본에도 동일한 0.1ms 반올림 차이가 있어 시각·출처·단위가 같은
표본은 0.1ms 이내 차이를 허용하고 먼저 저장된 값을 유지합니다. 다른 지표는 값이
정확히 일치해야 하며, 더 큰 차이는 파일 전체를 저장하지 않고 충돌을 알립니다.

## 수면 JSON v1 구조

업로드는 파일 선택에서 `.json` 파일을 선택하면 됩니다. MD와 같은 계산·계정별 DB·AI 코칭을 사용합니다.
아무 JSON이나 분석하는 것은 아니며 아래 구조를 지원합니다. MD는 기존 Health Data Export 형식을 유지합니다.

```json
{
  "schema_version": 1,
  "timezone": "Asia/Seoul",
  "source": "My Watch",
  "sessions": [
    {
      "start": "2026-11-01T23:00:00+09:00",
      "end": "2026-11-01T23:30:00+09:00",
      "segments": [
        {"start": "2026-11-01T23:00:00+09:00", "end": "2026-11-01T23:20:00+09:00", "stage": "core"},
        {"start": "2026-11-01T23:20:00+09:00", "end": "2026-11-01T23:30:00+09:00", "stage": "wake"}
      ]
    }
  ]
}
```

위 수치는 형식 설명을 위한 가상 기록입니다.

- 필수: `schema_version` (1), `timezone`, 하나 이상의 `sessions`
- `source`: 파일 최상위 또는 각 세션에 장치/출처 이름 필요
- 세션: `start`, `end`, 하나 이상의 `segments`
- 구간: `start`, `end`, `stage`
- `stage`: `core`, `deep`, `rem`, `wake`, `unspecified`
- 모든 시각: 연도와 시간대가 포함된 ISO 8601 (`+09:00`, `Z` 등)
- 구간은 시간순으로 정렬하고 세션 범위 안에 있어야 하며 겹치면 오류
- 빈 구간은 미기록으로 처리하며 수면이나 각성으로 임의 채우지 않음
- `asleep_minutes` 등 입력에 추가된 집계는 사용하지 않고 구간 시각으로 재계산

선택 사항: 세션의 `vitals_summary` 배열.

```json
{"metric": "heartRate", "unit": "bpm", "n": 3, "min": 60, "avg": 62, "max": 64}
```

각 항목에는 `metric`, `unit`, 표본 수 `n`이 필요합니다. 통계 수치는 JSON 숫자로,
없는 값은 생략하거나 null로 입력합니다. 사용할 수 있는 통계 키는 min/avg/max/p50/p90 및 단계 이름입니다.
기본 지표 이름은 heartRate, hrvSDNN, respiratoryRate, oxygenSaturation입니다.

선택 사항: 최상위 `samples` 배열로 개별 표본 저장.

```json
{"metric": "heartRate", "unit": "bpm", "source": "My Watch", "start": "2026-11-01T23:05:00+09:00", "value": 62}
```

`end`는 선택이며 없으면 점 측정으로 취급합니다. source는 최상위 값을 상속할 수 있습니다.
개별 표본은 DB에 보존하지만 생체지표 요약 표는 vitals_summary를 그대로 사용합니다.
samples만으로 생체지표 요약을 자동 생성하지 않습니다.

앱에서 **JSON 예제 다운로드**로 가상 예제를 받을 수 있습니다.
저장된 기록의 **선택 기록 JSON 다운로드**는 단계와 생체지표 요약을 내보냅니다.
같은 출처·시간·구간·생체지표를 MD와 JSON으로 각각 가져와도 같은 계정에 중복 저장하지 않습니다.
원본과 다른 수면 단계나 생체지표가 동일한 세션 시각에 들어오면 덮어쓰지 않고 충돌을 알립니다.
