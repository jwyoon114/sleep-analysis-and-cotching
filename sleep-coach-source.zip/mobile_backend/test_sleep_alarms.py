from contextlib import closing
from datetime import datetime,timezone
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import sleep_alarms as alarms
from coaching_service import extract_alarm_schedule
from sleep_accounts import register,erase_account_rows

class AlarmTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.db=Path(self.tmp.name)/'test.sqlite3'
        self.a=register('alarm-a','test-password-123',self.db)['id']
        self.b=register('alarm-b','test-password-123',self.db)['id']
        self.support=patch.object(alarms,'desktop_available',return_value=True)
        self.support.start()
    def tearDown(self):
        self.support.stop()
        self.tmp.cleanup()
    def save(self,**kwargs):
        return alarms.save_settings(self.a,'23:00','07:00','Asia/Seoul',True,db_path=self.db,**kwargs)
    def test_validation_and_isolation(self):
        self.save()
        self.assertFalse(alarms.get_settings(self.b,self.db)['enabled'])
        for bed,wake,zone in [('25:00','07:00','Asia/Seoul'),('07:00','07:00','Asia/Seoul'),('23:00','07:00','Invalid/Zone')]:
            with self.assertRaises(ValueError): alarms.save_settings(self.a,bed,wake,zone,True,db_path=self.db)
        with self.assertRaises(ValueError): self.save(coaching_id='foreign-or-missing')
    def test_once_daily_midnight_and_restart(self):
        self.save()
        with closing(alarms.connect(self.db)) as db,db:
            db.execute("UPDATE sleep_alarm_settings SET updated_at='2026-01-01T00:00:00+00:00'")
        fired=[]
        def tick(stamp): return alarms.tick(datetime.fromisoformat(stamp),self.db,fired.append)
        self.assertEqual(tick('2026-11-07T14:00:05+00:00'),['bedtime'])
        self.assertEqual(tick('2026-11-07T14:00:40+00:00'),[])
        self.assertEqual(tick('2026-11-07T22:00:05+00:00'),['wake_time'])
        self.assertEqual(tick('2026-11-08T14:00:05+00:00'),['bedtime'])
        self.assertEqual(tick('2026-11-08T23:00:00+00:00'),[])
    def test_disabled_and_account_removal(self):
        self.save()
        alarms.save_settings(self.a,'23:00','07:00','Asia/Seoul',False,db_path=self.db)
        self.assertEqual(alarms.tick(datetime.now(timezone.utc),self.db,lambda _:self.fail('rang')),[])
        with closing(alarms.connect(self.db)) as db,db:
            erase_account_rows(db,self.a)
            self.assertEqual(db.execute('SELECT count(*) FROM sleep_alarm_settings').fetchone()[0],0)
    def test_newly_enabled_time_is_not_replayed(self):
        now=datetime.now(timezone.utc)
        hm=now.strftime('%H:%M')
        other='00:00' if hm!='00:00' else '01:00'
        alarms.save_settings(self.a,hm,other,'UTC',True,db_path=self.db)
        self.assertEqual(alarms.tick(now,self.db,lambda _:self.fail('rang')),[])
    def test_ai_schedule_is_explicit_and_validated(self):
        text,proposal=extract_alarm_schedule('조언입니다.\nALARM_SCHEDULE: {"bedtime":"23:15","wake_time":"07:15","reason":"기록 기반"}','Asia/Seoul')
        self.assertEqual(text,'조언입니다.')
        self.assertEqual(proposal['bedtime'],'23:15')
        self.assertIsNone(extract_alarm_schedule('예전 코칭입니다.','Asia/Seoul')[1])
        self.assertIsNone(extract_alarm_schedule('조언\nALARM_SCHEDULE: {"bedtime":"25:00"}','Asia/Seoul')[1])

    def test_api_requires_auth_and_scopes_settings(self):
        import health_records
        from api import app
        from fastapi.testclient import TestClient
        from sleep_accounts import login
        with patch.object(health_records,'DB_PATH',self.db),patch.object(alarms,'start_worker'),TestClient(app) as client:
            self.assertEqual(client.get('/alarms').status_code,401)
            a={'Authorization':'Bearer '+login('alarm-a','test-password-123',self.db)['token']}
            b={'Authorization':'Bearer '+login('alarm-b','test-password-123',self.db)['token']}
            body=dict(bedtime='23:00',wake_time='07:00',timezone='Asia/Seoul',enabled=True)
            self.assertEqual(client.post('/alarms',json=body,headers=a).status_code,200)
            self.assertFalse(client.get('/alarms',headers=b).json()['enabled'])
            self.assertEqual(client.post('/alarms',json=body|{'bedtime':'25:00'},headers=a).status_code,422)
            with patch.object(alarms,'notify') as notify:
                self.assertEqual(client.post('/alarms/test',headers=a).status_code,200)
                notify.assert_called_once_with('bedtime')

if __name__=='__main__': unittest.main()
