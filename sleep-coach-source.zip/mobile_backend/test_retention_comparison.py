from contextlib import closing
from datetime import date, datetime, timedelta, timezone
import json
import os
from pathlib import Path
import sqlite3
import tempfile
import unittest
from unittest.mock import patch

import health_records
from backup_policy import create_backup, maintain_backups, managed_backups
from health_records import connect, delete_session, import_export, list_sessions
from history_service import compare_periods, expire_trash, purge_record, restore_record, trash_history
from sleep_accounts import register
from test_health_records import FIXTURE


class ComparisonTest(unittest.TestCase):
    def test_calendar_windows_gaps_and_same_day_totals(self):
        def record(day, asleep, awake):
            return {"start": f"2026-11-{day:02}T02:00:00+09:00", "asleep_minutes": asleep, "awake_minutes": awake}
        records = [record(14, 120, 10), record(14, 60, 5), record(8, 240, 20), record(7, 300, 30), record(1, 100, 10)]
        result = compare_periods(records, date(2026, 11, 14), 7)
        current, previous = result["current"], result["previous"]
        self.assertEqual((current["start"], current["end"]), ("2026-11-08", "2026-11-14"))
        self.assertEqual((previous["start"], previous["end"]), ("2026-11-01", "2026-11-07"))
        self.assertEqual(current["session_count"], 3)
        self.assertEqual(current["recorded_days"], 2)
        self.assertEqual(current["average_asleep_minutes_per_recorded_day"], 210)
        self.assertEqual(current["average_awake_minutes_per_recorded_day"], 17.5)
        self.assertIsNone(current["daily"][1]["asleep_minutes"])
        self.assertEqual(current["daily"][-1]["asleep_minutes"], 180)

    def test_empty_and_30_day_year_boundary(self):
        result = compare_periods([], "2027-01-02", 30)
        self.assertEqual(result["current"]["start"], "2026-12-04")
        self.assertEqual(len(result["previous"]["daily"]), 30)
        self.assertIsNone(result["current"]["average_asleep_minutes_per_recorded_day"])
        with self.assertRaises(ValueError):
            compare_periods([], "2027-01-02", 1)


class RetentionTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.db = Path(self.tmp.name) / "sleep.sqlite3"
        patcher = patch.object(health_records, "DB_PATH", self.db)
        patcher.start()
        self.addCleanup(patcher.stop)
        self.owner = register("retention-a", "test-password-123")["id"]
        self.other = register("retention-b", "test-password-123")["id"]
        self.sid = import_export(FIXTURE, "test.md", self.owner)["analysis_ids"][0]
        self.other_sid = import_export(FIXTURE, "test.md", self.other)["analysis_ids"][0]

    def test_restore_keeps_individually_trashed_coaching_hidden(self):
        import coaching_service
        with closing(connect()) as db, db:
            db.execute("INSERT INTO coaching VALUES(?,?,?,?,?,?)", ("separate", self.owner, self.sid, "가상 조언", "{}", "2026-11-05T00:00:00+00:00"))
        coaching_service.delete_coaching(self.owner, self.sid, "separate")
        delete_session(self.sid, self.owner)
        self.assertFalse(restore_record("coaching", "separate", self.owner))
        self.assertTrue(restore_record("session", self.sid, self.owner))
        self.assertEqual(coaching_service.list_coaching(self.owner, self.sid), [])
        self.assertTrue(restore_record("coaching", "separate", self.owner))
        self.assertEqual(len(coaching_service.list_coaching(self.owner, self.sid)), 1)

    def test_expiry_is_scoped_and_not_premature(self):
        delete_session(self.sid, self.owner)
        delete_session(self.other_sid, self.other)
        now = datetime.now(timezone.utc)
        with closing(connect()) as db, db:
            db.execute("UPDATE trash_sessions SET deleted_at=?", ((now - timedelta(days=31)).isoformat(),))
        self.assertFalse(restore_record("session", self.sid, self.owner))
        self.assertEqual(expire_trash(self.owner, now=now), 1)
        self.assertEqual(len(trash_history(self.other)["sessions"]), 1)
        with closing(connect()) as db:
            self.assertFalse(db.execute("SELECT 1 FROM sessions WHERE id=?", (self.sid,)).fetchone())
            self.assertTrue(db.execute("SELECT 1 FROM sessions WHERE id=?", (self.other_sid,)).fetchone())
        self.assertFalse(purge_record("session", self.other_sid, self.owner))

    def test_backup_sanitization_and_reimport_generation(self):
        create_backup()
        original = managed_backups()[0]
        with closing(sqlite3.connect(original)) as backup:
            self.assertEqual(backup.execute("SELECT count(*) FROM sessions").fetchone()[0], 2)
        delete_session(self.sid, self.owner)
        self.assertTrue(purge_record("session", self.sid, self.owner))
        with closing(sqlite3.connect(original)) as backup:
            self.assertFalse(backup.execute("SELECT 1 FROM sessions WHERE id=?", (self.sid,)).fetchone())
            self.assertTrue(backup.execute("SELECT 1 FROM sessions WHERE id=?", (self.other_sid,)).fetchone())
            self.assertEqual(backup.execute("PRAGMA foreign_key_check").fetchall(), [])
        # Re-upload is a new generation and must survive future backup cleanup.
        import_export(FIXTURE, "test.md", self.owner)
        create_backup()
        newest = max(managed_backups(), key=lambda p: p.stat().st_mtime)
        maintain_backups()
        with closing(sqlite3.connect(newest)) as backup:
            self.assertTrue(backup.execute("SELECT 1 FROM sessions WHERE id=?", (self.sid,)).fetchone())

    def test_old_schema_snapshot_cleanup_and_retention_scope(self):
        create_backup()
        backup = managed_backups()[0]
        # Emulate snapshots made before the new tables existed.
        with closing(sqlite3.connect(backup)) as db, db:
            for table in ("coaching_context", "trash_coaching", "trash_sessions", "session_created", "permanent_deletions", "coaching"):
                db.execute(f"DROP TABLE {table}")
        delete_session(self.sid, self.owner)
        self.assertTrue(purge_record("session", self.sid, self.owner))
        with closing(sqlite3.connect(backup)) as db:
            self.assertFalse(db.execute("SELECT 1 FROM sessions WHERE id=?", (self.sid,)).fetchone())
        external = self.db.with_name("user-copy.bak")
        external.write_bytes(backup.read_bytes())
        old = (datetime.now(timezone.utc) - timedelta(days=31)).timestamp()
        os.utime(backup, (old, old))
        os.utime(external, (old, old))
        self.assertEqual(maintain_backups()["expired"], 1)
        self.assertTrue(external.exists())
        self.assertTrue(self.db.exists())

    def test_locked_backup_retries_from_durable_deletion_ledger(self):
        create_backup()
        snapshot = managed_backups()[0]
        real_connect = sqlite3.connect
        def block_snapshot(path, *args, **kwargs):
            if str(snapshot.as_uri()) in str(path):
                raise sqlite3.OperationalError("locked")
            return real_connect(path, *args, **kwargs)
        delete_session(self.sid, self.owner)
        with patch("backup_policy.sqlite3.connect", side_effect=block_snapshot):
            self.assertTrue(purge_record("session", self.sid, self.owner))
            self.assertEqual(maintain_backups()["pending"], 1)
        self.assertEqual(maintain_backups()["pending"], 0)
        with closing(sqlite3.connect(snapshot)) as db:
            self.assertFalse(db.execute("SELECT 1 FROM sessions WHERE id=?", (self.sid,)).fetchone())

    def test_purging_record_removes_referenced_context_snapshots(self):
        second = import_export(FIXTURE.replace("Test Watch", "Second Watch"), "second.md", self.owner)["analysis_ids"][0]
        with closing(connect()) as db, db:
            db.execute("INSERT INTO coaching VALUES(?,?,?,?,?,?)", ("context-coach", self.owner, second, "가상 조언", "{}", "2026-11-05T00:00:00+00:00"))
            db.execute("INSERT INTO coaching_context VALUES(?,?)", ("context-coach", json.dumps({"record_ids": [self.sid, second]})))
        delete_session(self.sid, self.owner)
        purge_record("session", self.sid, self.owner)
        with closing(connect()) as db:
            self.assertFalse(db.execute("SELECT 1 FROM coaching_context").fetchone())
            self.assertTrue(db.execute("SELECT 1 FROM coaching WHERE id='context-coach'").fetchone())


if __name__ == "__main__":
    unittest.main()
