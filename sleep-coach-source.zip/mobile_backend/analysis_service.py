"""Copy beside the existing predict.py and models/ directory."""
from pathlib import Path
import math

import joblib
import mne
import numpy as np

from predict import BANDS, STAGE_NAMES, extract_features


def analyze_edf(edf_path, model_path, start_minutes=0.0, end_minutes=None):
    if not math.isfinite(start_minutes) or start_minutes < 0:
        raise ValueError("시작 시간은 0 이상의 유한한 값이어야 합니다.")
    if end_minutes is not None and not math.isfinite(end_minutes):
        raise ValueError("종료 시간이 올바르지 않습니다.")
    for value in (start_minutes, end_minutes):
        if value is not None and not math.isclose(value * 2, round(value * 2)):
            raise ValueError("시간은 0.5분(30초) 단위로 지정하세요.")

    model_path = Path(model_path)
    if not model_path.is_file():
        raise FileNotFoundError("models/sleep_rf.joblib이 없습니다.")
    bundle = joblib.load(model_path)
    if list(bundle["feature_names"]) != list(BANDS):
        raise ValueError("모델과 특징 추출 코드의 순서가 다릅니다.")

    raw = mne.io.read_raw_edf(
        edf_path, include=["EEG Fpz-Cz"], preload=True, verbose=False
    )
    try:
        if raw.ch_names != ["EEG Fpz-Cz"]:
            raise ValueError("EEG Fpz-Cz 채널이 필요합니다.")
        sfreq = raw.info["sfreq"]
        if not np.isclose(sfreq, 100.0):
            raise ValueError("현재 모델은 100Hz EEG를 지원합니다.")
        recording_seconds = raw.n_times / sfreq
        complete_count = raw.n_times // int(30 * sfreq)
        end = complete_count / 2 if end_minutes is None else end_minutes
        start_index = round(start_minutes * 2)
        end_index = round(end * 2)
        if not 0 <= start_index < end_index <= complete_count:
            raise ValueError(
                f"분석 범위는 0~{complete_count / 2:.1f}분 이내이며 "
                "최소 0.5분이어야 합니다."
            )

        raw.set_annotations(None)
        raw.filter(0.5, 30.0, picks="eeg", verbose=False)
        epochs = mne.make_fixed_length_epochs(
            raw, duration=30.0, overlap=0.0, preload=True,
            reject_by_annotation=False, verbose=False,
        )
        eeg = epochs[start_index:end_index].get_data(copy=True)[:, 0, :]
        features = extract_features(eeg, sfreq)
        predictions = bundle["model"].predict(features)
    finally:
        raw.close()

    return {
        "recording_minutes": recording_seconds / 60,
        "start_minutes": start_minutes,
        "end_minutes": end,
        "analyzed_minutes": len(predictions) * 0.5,
        "predicted_sleep_minutes": float(np.sum(predictions != 1) * 0.5),
        "predicted_wake_minutes": float(np.sum(predictions == 1) * 0.5),
        "predicted_stage_minutes": {
            name: float(np.sum(predictions == label) * 0.5)
            for label, name in STAGE_NAMES.items()
        },
        "epochs": [
            {
                "start_seconds": (start_index + i) * 30,
                "end_seconds": (start_index + i + 1) * 30,
                "predicted_stage": STAGE_NAMES[int(label)],
            }
            for i, label in enumerate(predictions)
        ],
    }
