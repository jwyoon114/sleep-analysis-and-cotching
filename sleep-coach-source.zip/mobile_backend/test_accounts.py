from contextlib import closing
from datetime import datetime, timezone, timedelta
import json
from pathlib import Path
import sqlite3
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import coaching_service
from health_records import connect, digest, get_owned_session, import_export, list_sessions, overview
from sleep_accounts import AuthenticationError, current_user, login, logout, register
from test_health_records import FIXTURE


class AccountsTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Path(self.tmp.name) / "sleep.sqlite3"

    def tearDown(self):
        self.tmp.cleanup()

    def test_credentials_expiry_and_revocation(self):
        user = register("User-A", "test-password-123", self.db)
        with self.assertRaises(ValueError):
            register("USER-A", "test-password-123", self.db)
        with self.assertRaises(AuthenticationError):
            login("user-a", "incorrect-password", self.db)
        auth = login("USER-A", "test-password-123", self.db)
        self.assertEqual(current_user(auth["token"], self.db), user)
        with closing(connect(self.db)) as db, db:
            row = db.execute("SELECT * FROM accounts").fetchone()
            self.assertNotEqual(row["password_hash"], "test-password-123")
            self.assertFalse(db.execute("SELECT 1 FROM auth_tokens WHERE token_hash=?", (auth["token"],)).fetchone())
            db.execute("UPDATE auth_tokens SET expires_at=?", ((datetime.now(timezone.utc) - timedelta(seconds=1)).isoformat(),))
        with self.assertRaises(AuthenticationError):
            current_user(auth["token"], self.db)
        auth = login("user-a", "test-password-123", self.db)
        logout(auth["token"], self.db)
        with self.assertRaises(AuthenticationError):
            current_user(auth["token"], self.db)

    def test_account_isolation_and_coaching_persistence(self):
        a = register("person-a", "test-password-123", self.db)
        b = register("person-b", "test-password-456", self.db)
        result = import_export(FIXTURE, "sleep.md", a["id"], self.db)
        sid = result["analysis_ids"][0]
        self.assertFalse(list_sessions(b["id"], self.db))
        self.assertIsNone(get_owned_session(sid, b["id"], self.db))
        with patch.object(coaching_service, "settings") as settings:
            with self.assertRaises(LookupError):
                coaching_service.generate(b["id"], sid, {}, self.db)
            settings.assert_not_called()
        with patch.object(coaching_service, "settings", return_value=("fake", "test-model")), patch.object(coaching_service, "OpenAI") as client:
            create = client.return_value.__enter__.return_value.responses.create
            create.return_value = SimpleNamespace(status="completed", output_text="테스트용 조언")
            result = coaching_service.generate(a["id"], sid, {"caffeine": "없음"}, self.db)
            self.assertEqual(result["context"]["model"], "test-model")
            self.assertEqual(result["context"]["record_count"], 1)
            self.assertEqual(result["context"]["input_summary"]["lifestyle"]["caffeine"], "없음")
            payload = json.loads(create.call_args.kwargs["input"])
            self.assertNotIn("Test Watch", create.call_args.kwargs["input"])
            self.assertNotIn(a["id"], create.call_args.kwargs["input"])
            self.assertEqual(payload["lifestyle"]["caffeine"], "없음")
        self.assertEqual(coaching_service.latest_coaching(a["id"], sid, self.db)["coaching"], "테스트용 조언")
        self.assertIsNone(coaching_service.latest_coaching(b["id"], sid, self.db))

    def test_missing_days_are_excluded_from_average(self):
        records = [dict(start="2026-11-01T03:00:00+09:00", asleep_minutes=120, awake_minutes=10),
                   dict(start="2026-11-01T15:00:00+09:00", asleep_minutes=30, awake_minutes=0),
                   dict(start="2026-11-04T02:00:00+09:00", asleep_minutes=210, awake_minutes=5)]
        result = overview(records)
        self.assertEqual(result["recorded_days"], 2)
        self.assertEqual(result["average_asleep_minutes_per_recorded_day"], 180)
        self.assertEqual(result["daily"][0]["session_count"], 2)

    def test_login_throttle(self):
        register("person-a", "test-password-123", self.db)
        for _ in range(5):
            with self.assertRaises(AuthenticationError):
                login("person-a", "wrong", self.db)
        with self.assertRaisesRegex(AuthenticationError, "10분"):
            login("person-a", "test-password-123", self.db)


if __name__ == "__main__":
    unittest.main()
