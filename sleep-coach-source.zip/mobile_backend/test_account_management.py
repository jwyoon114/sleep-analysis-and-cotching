"""Account changes and deletion use synthetic users and temporary databases."""
from contextlib import closing
import json
from pathlib import Path
import sqlite3
import sys
import tempfile
import unittest
from unittest.mock import patch

import health_records
from backup_policy import create_backup, maintain_backups, managed_backups
from health_records import connect, delete_session, import_export, list_sessions
from sleep_accounts import AuthenticationError, current_user, delete_account, login, register, update_account
from test_health_records import FIXTURE


class AccountManagementTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.db = Path(self.tmp.name) / "accounts.sqlite3"
        patcher = patch.object(health_records, "DB_PATH", self.db)
        patcher.start()
        self.addCleanup(patcher.stop)
        self.a = register("settings-a", "old-password-123")
        self.b = register("settings-b", "other-password-123")
        self.sid = import_export(FIXTURE, "test.md", self.a["id"])["analysis_ids"][0]
        self.bid = import_export(FIXTURE, "test.md", self.b["id"])["analysis_ids"][0]
        self.at = login("settings-a", "old-password-123")["token"]
        self.bt = login("settings-b", "other-password-123")["token"]

    def test_username_change_preserves_records_and_revokes_all_tokens(self):
        second = login("settings-a", "old-password-123")["token"]
        result = update_account(self.a["id"], "old-password-123", new_username=" NEW-Name ")
        self.assertEqual(result["username"], "new-name")
        self.assertEqual(result["id"], self.a["id"])
        self.assertEqual(list_sessions(self.a["id"])[0]["analysis_id"], self.sid)
        for token in (self.at, second):
            with self.assertRaises(AuthenticationError):
                current_user(token)
        with self.assertRaises(AuthenticationError):
            login("settings-a", "old-password-123")
        self.assertEqual(login("new-name", "old-password-123")["user"]["id"], self.a["id"])
        self.assertEqual(current_user(self.bt), self.b)

    def test_password_change_rotates_salt_and_keeps_data(self):
        with closing(connect()) as db:
            before = db.execute("SELECT salt, password_hash FROM accounts WHERE id=?", (self.a["id"],)).fetchone()
        update_account(self.a["id"], "old-password-123", new_password="new-password-456")
        with closing(connect()) as db:
            after = db.execute("SELECT salt, password_hash FROM accounts WHERE id=?", (self.a["id"],)).fetchone()
        self.assertNotEqual(before["salt"], after["salt"])
        self.assertNotEqual(before["password_hash"], after["password_hash"])
        with self.assertRaises(AuthenticationError):
            current_user(self.at)
        with self.assertRaises(AuthenticationError):
            login("settings-a", "old-password-123")
        self.assertEqual(login("settings-a", "new-password-456")["user"], self.a)
        self.assertEqual(len(list_sessions(self.a["id"])), 1)

    def test_rejected_changes_keep_account_and_token(self):
        for kwargs in ({}, {"new_username": "settings-b"}, {"new_username": "settings-a"}, {"new_username": "x"}, {"new_password": "short"}):
            with self.assertRaises(ValueError):
                update_account(self.a["id"], "old-password-123", **kwargs)
        with self.assertRaises(AuthenticationError):
            update_account(self.a["id"], "wrong-password", new_username="changed-a")
        with self.assertRaises(ValueError):
            delete_account(self.a["id"], "old-password-123", "wrong confirmation")
        with self.assertRaises(AuthenticationError):
            delete_account(self.a["id"], "wrong-password", "계정 삭제")
        self.assertEqual(current_user(self.at), self.a)
        self.assertEqual(len(list_sessions(self.a["id"])), 1)

    def test_account_action_failures_are_committed_and_throttled(self):
        for _ in range(5):
            with self.assertRaises(AuthenticationError):
                update_account(self.a["id"], "wrong-password", new_username="changed-a")
        with self.assertRaisesRegex(AuthenticationError, "10분"):
            delete_account(self.a["id"], "old-password-123", "계정 삭제")
        with closing(connect()) as db:
            self.assertEqual(db.execute("SELECT count(*) FROM login_attempts WHERE username=?", (self.a["username"],)).fetchone()[0], 5)
        self.assertEqual(current_user(self.bt), self.b)

    def test_account_delete_cleans_trash_samples_context_and_backups(self):
        import coaching_service
        with closing(connect()) as db, db:
            for owner, sid, cid in ((self.a["id"], self.sid, "a-coach"), (self.b["id"], self.bid, "b-coach")):
                db.execute("INSERT INTO coaching VALUES(?,?,?,?,?,?)", (cid, owner, sid, "가상 코칭", "{}", "2026-11-05T00:00:00+00:00"))
                db.execute("INSERT INTO coaching_context VALUES(?,?)", (cid, json.dumps({"record_ids": [sid]})))
                db.execute("INSERT INTO samples VALUES(?,?,?,?,?,?,?,?)", (owner, owner, "Heart Rate", "Test Watch", "bpm", "2026-01-01T00:00:00+09:00", "2026-01-01T00:00:00+09:00", 60))
            db.execute("INSERT INTO login_attempts VALUES(?,?)", (self.a["username"], "2026-11-05T00:00:00+00:00"))
        create_backup()
        update_account(self.a["id"], "old-password-123", new_username="renamed-a")
        coaching_service.delete_coaching(self.a["id"], self.sid, "a-coach")
        delete_session(self.sid, self.a["id"])
        create_backup()
        result = delete_account(self.a["id"], "old-password-123", "계정 삭제")
        self.assertEqual(result["backups"]["pending"], 0)
        for path in [self.db] + managed_backups():
            with closing(sqlite3.connect(path)) as db:
                self.assertFalse(db.execute("SELECT 1 FROM accounts WHERE id=?", (self.a["id"],)).fetchone())
                self.assertFalse(db.execute("SELECT 1 FROM sessions WHERE subject=?", (self.a["id"],)).fetchone())
                self.assertFalse(db.execute("SELECT 1 FROM samples WHERE subject=?", (self.a["id"],)).fetchone())
                self.assertFalse(db.execute("SELECT 1 FROM coaching WHERE account_id=?", (self.a["id"],)).fetchone())
                self.assertFalse(db.execute("SELECT 1 FROM auth_tokens WHERE account_id=?", (self.a["id"],)).fetchone())
                self.assertFalse(db.execute("SELECT 1 FROM coaching_context WHERE coaching_id='a-coach'").fetchone())
                self.assertTrue(db.execute("SELECT 1 FROM accounts WHERE id=?", (self.b["id"],)).fetchone())
                self.assertTrue(db.execute("SELECT 1 FROM sessions WHERE id=?", (self.bid,)).fetchone())
                self.assertTrue(db.execute("SELECT 1 FROM samples WHERE subject=?", (self.b["id"],)).fetchone())
                self.assertTrue(db.execute("SELECT 1 FROM coaching WHERE id='b-coach'").fetchone())
                self.assertEqual(db.execute("PRAGMA foreign_key_check").fetchall(), [])
        with self.assertRaises(AuthenticationError):
            current_user(self.at)
        self.assertEqual(current_user(self.bt), self.b)
        fresh = register("renamed-a", "fresh-password-123")
        self.assertNotEqual(fresh["id"], self.a["id"])
        self.assertEqual(list_sessions(fresh["id"]), [])

    def test_http_only_acts_on_authenticated_account(self):
        from fastapi.testclient import TestClient
        from api import app
        a = {"Authorization": "Bearer " + self.at}
        b = {"Authorization": "Bearer " + self.bt}
        with TestClient(app) as client:
            change = {"current_password": "old-password-123", "new_username": "api-renamed"}
            self.assertEqual(client.patch("/auth/me", json=change).status_code, 401)
            self.assertEqual(client.patch("/auth/me", headers=b, json=change).status_code, 403)
            self.assertEqual(client.patch("/auth/me", headers=a, json=change | {"account_id": self.b["id"]}).status_code, 422)
            self.assertEqual(client.patch("/auth/me", headers=a, json=change).status_code, 200)
            self.assertEqual(client.get("/auth/me", headers=a).status_code, 401)
            new_token = login("api-renamed", "old-password-123")["token"]
            a = {"Authorization": "Bearer " + new_token}
            deletion = {"current_password": "old-password-123", "confirmation": "계정 삭제"}
            self.assertEqual(client.request("DELETE", "/auth/me", headers=a, json=deletion | {"confirmation": "wrong"}).status_code, 422)
            self.assertEqual(client.request("DELETE", "/auth/me", headers=a, json=deletion).status_code, 200)
            self.assertEqual(client.get("/auth/me", headers=a).status_code, 401)
            self.assertEqual(client.get("/auth/me", headers=b).status_code, 200)

    def test_streamlit_settings_change_password_and_delete(self):
        from streamlit.testing.v1 import AppTest
        root = Path(__file__).resolve().parent.parent
        sys.path.insert(0, str(root / "streamlit_clock_update"))
        self.addCleanup(sys.path.remove, str(root / "streamlit_clock_update"))
        screen = AppTest.from_file(str(root / "streamlit_clock_update" / "app.py"), default_timeout=45)
        screen.session_state["auth_token"] = self.at
        screen.run()
        screen.radio(key="main_menu").set_value("계정 설정").run()
        self.assertFalse(screen.exception)
        screen.text_input(key="account_current_password").set_value("old-password-123")
        screen.text_input(key="account_new_password").set_value("new-password-456")
        screen.text_input(key="account_confirm_password").set_value("different-password")
        next(b for b in screen.button if b.label == "비밀번호 변경").click().run()
        self.assertTrue(screen.error)
        self.assertEqual(current_user(self.at), self.a)
        screen.text_input(key="account_confirm_password").set_value("new-password-456")
        next(b for b in screen.button if b.label == "비밀번호 변경").click().run()
        self.assertFalse(screen.exception)
        self.assertEqual(len(screen.text_input), 5)
        screen.text_input(key="login_name").set_value("settings-a")
        screen.text_input(key="login_password").set_value("new-password-456")
        next(b for b in screen.button if b.label == "로그인").click().run()
        screen.radio(key="main_menu").set_value("계정 설정").run()
        screen.text_input(key="account_delete_password").set_value("new-password-456")
        screen.text_input(key="account_delete_confirmation").set_value("계정 삭제")
        next(b for b in screen.button if b.label == "계정 영구 삭제").click().run()
        self.assertTrue(screen.error)
        screen.checkbox(key="account_delete_agreed").check()
        next(b for b in screen.button if b.label == "계정 영구 삭제").click().run()
        self.assertFalse(screen.exception)
        self.assertEqual(len(screen.text_input), 5)
        with self.assertRaises(AuthenticationError):
            login("settings-a", "new-password-456")
        self.assertEqual(current_user(self.bt), self.b)


if __name__ == "__main__":
    unittest.main()
