from contextlib import closing
from pathlib import Path
import sqlite3
import sys

PROJECT = Path(r"C:\Users\jwyoo\Desktop\인하대 2-2\PythonProject1")
sys.path.insert(0, str(PROJECT))
import api
assert api.health()["service"] == "wearable_sleep"
assert any(".json" in f for f in api.health()["supported_formats"])
from json_sleep import EXAMPLE_JSON, parse_json_export
assert parse_json_export(EXAMPLE_JSON)["sessions"][0]["asleep_minutes"] == 55
from health_records import parse_export, same_observation
folder = Path(r"C:\Users\jwyoo\Documents\카카오톡 받은 파일")
md = folder / "health-export-md-2026-11-05-0000_to_2026-11-05-1033.md"
js = folder / "health-export-json-2026-11-05-0000_to_2026-11-05-1033.json"
if md.is_file() and js.is_file():
    a = parse_export(md.read_text(encoding="utf-8-sig"))
    b = parse_json_export(js.read_text(encoding="utf-8-sig"))
    assert len(a["samples"]) == len(b["samples"]) == 225
    assert same_observation(a["sessions"][0], b["sessions"][0])
    print("INSTALLED_ACTUAL_MD_JSON_PAIR_OK")
assert "analysis_service" not in sys.modules
with closing(sqlite3.connect(PROJECT / "data" / "sleep_records.sqlite3")) as db:
    assert db.execute("SELECT count(*) FROM sessions WHERE subject='apple_watch_owner'").fetchone()[0] == 5
    assert db.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
from streamlit.testing.v1 import AppTest
screen = AppTest.from_file(str(PROJECT / "app.py"), default_timeout=45).run()
assert not screen.exception, [e.message for e in screen.exception]
assert screen.title[0].value == "나의 수면 리포트"
assert len(screen.text_input) == 5
assert not screen.dataframe
print("INSTALLED_OK: wearable service, private login screen, legacy data preserved; no EEG imports")
