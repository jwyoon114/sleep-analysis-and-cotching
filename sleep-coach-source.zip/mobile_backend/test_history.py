"""History and destructive actions run only against temporary databases."""
from contextlib import closing
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import coaching_service
import health_records
from history_service import purge_record, restore_record, trash_history
from health_records import connect, delete_session, import_export, list_sessions
from sleep_accounts import login, register
from test_health_records import FIXTURE


class HistoryTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.db = Path(self.tmp.name) / "history.sqlite3"
        self.patcher = patch.object(health_records, "DB_PATH", self.db)
        self.patcher.start()
        self.addCleanup(self.patcher.stop)
        self.a = register("history-a", "test-password-123")
        self.b = register("history-b", "test-password-456")
        self.sid = import_export(FIXTURE, "test.md", self.a["id"])["analysis_ids"][0]
        with closing(connect()) as db, db:
            for index in (1, 2):
                db.execute("INSERT INTO coaching VALUES(?,?,?,?,?,?)", (f"coach-{index}", self.a["id"], self.sid, f"가상 조언 {index}", json.dumps({"caffeine": "없음"}), f"2026-11-0{index}T00:00:00+00:00"))

    def test_history_and_individual_coaching_deletion(self):
        history = coaching_service.list_coaching(self.a["id"], self.sid)
        self.assertEqual([c["id"] for c in history], ["coach-2", "coach-1"])
        self.assertEqual(history[0]["lifestyle"], {"caffeine": "없음"})
        self.assertEqual(coaching_service.list_coaching(self.b["id"], self.sid), [])
        self.assertFalse(coaching_service.delete_coaching(self.b["id"], self.sid, "coach-2"))
        self.assertTrue(coaching_service.delete_coaching(self.a["id"], self.sid, "coach-2"))
        self.assertEqual(coaching_service.latest_coaching(self.a["id"], self.sid)["id"], "coach-1")
        self.assertEqual(len(list_sessions(self.a["id"])), 1)

    def test_analysis_cleanup_other_account_and_reimport(self):
        other = import_export(FIXTURE, "test.md", self.b["id"])["analysis_ids"][0]
        self.assertFalse(delete_session(self.sid, self.b["id"]))
        self.assertTrue(delete_session(self.sid, self.a["id"]))
        self.assertFalse(delete_session(self.sid, self.a["id"]))
        self.assertEqual(list_sessions(self.a["id"]), [])
        self.assertEqual(coaching_service.list_coaching(self.a["id"], self.sid), [])
        with self.assertRaisesRegex(ValueError, "휴지통"):
            import_export(FIXTURE, "test.md", self.a["id"])
        self.assertTrue(restore_record("session", self.sid, self.a["id"]))
        self.assertEqual(len(coaching_service.list_coaching(self.a["id"], self.sid)), 2)
        delete_session(self.sid, self.a["id"])
        self.assertFalse(purge_record("session", self.sid, self.b["id"]))
        self.assertTrue(purge_record("session", self.sid, self.a["id"]))
        with closing(connect()) as db:
            for table, column in (("stages", "session_id"), ("coaching", "session_id"), ("import_sessions", "session_id")):
                self.assertEqual(db.execute(f"SELECT count(*) FROM {table} WHERE {column}=?", (self.sid,)).fetchone()[0], 0)
            self.assertEqual(db.execute("SELECT count(*) FROM imports WHERE subject=?", (self.a["id"],)).fetchone()[0], 0)
            self.assertEqual(db.execute("PRAGMA foreign_key_check").fetchall(), [])
        self.assertEqual(list_sessions(self.b["id"])[0]["analysis_id"], other)
        self.assertEqual(import_export(FIXTURE, "test.md", self.a["id"])["added_sessions"], 1)

    def test_shared_samples_survive_until_last_analysis_deleted(self):
        second = import_export(FIXTURE.replace("Test Watch", "Second Watch"), "second.md", self.a["id"])["analysis_ids"][0]
        with closing(connect()) as db, db:
            db.execute("INSERT INTO samples VALUES(?,?,?,?,?,?,?,?)", ("shared", self.a["id"], "Heart Rate", "Test Watch", "bpm", "2027-01-01T00:00:00+09:00", "2027-01-01T00:00:00+09:00", 60))
        delete_session(self.sid, self.a["id"])
        purge_record("session", self.sid, self.a["id"])
        with closing(connect()) as db:
            self.assertEqual(db.execute("SELECT count(*) FROM samples").fetchone()[0], 1)
        delete_session(second, self.a["id"])
        purge_record("session", second, self.a["id"])
        with closing(connect()) as db:
            self.assertEqual(db.execute("SELECT count(*) FROM samples").fetchone()[0], 0)

    def test_http_history_auth_and_deletion(self):
        from fastapi.testclient import TestClient
        from api import app
        with TestClient(app) as client:
            path = f"/watch/sessions/{self.sid}"
            a = {"Authorization": "Bearer " + login("history-a", "test-password-123")["token"]}
            b = {"Authorization": "Bearer " + login("history-b", "test-password-456")["token"]}
            self.assertEqual(client.delete(path).status_code, 401)
            self.assertEqual(client.delete(path, headers=b).status_code, 404)
            self.assertEqual(client.delete(path + "/coaching/coach-2", headers=b).status_code, 404)
            self.assertEqual(client.get(path + "/coaching", headers=b).status_code, 404)
            self.assertEqual(len(client.get(path + "/coaching", headers=a).json()["history"]), 2)
            self.assertEqual(client.delete(path + "/coaching/coach-2", headers=a).status_code, 200)
            self.assertEqual(client.get(path + "/coaching", headers=a).json()["result"]["id"], "coach-1")
            self.assertEqual(client.delete(path, headers=a).status_code, 200)
            self.assertEqual(client.get(path, headers=a).status_code, 404)
            trash_path = f"/watch/trash/session/{self.sid}"
            self.assertEqual(len(client.get("/watch/trash", headers=a).json()["sessions"]), 1)
            self.assertEqual(client.post(trash_path + "/restore", headers=b).status_code, 404)
            self.assertEqual(client.delete(trash_path, headers=b).status_code, 404)
            self.assertEqual(client.post(trash_path + "/restore", headers=a).status_code, 200)
            self.assertEqual(client.get(path, headers=a).status_code, 200)
            coach_path = "/watch/trash/coaching/coach-2"
            self.assertEqual(client.post(coach_path + "/restore", headers=b).status_code, 404)
            self.assertEqual(client.post(coach_path + "/restore", headers=a).status_code, 200)
            self.assertEqual(client.delete(path, headers=a).status_code, 200)
            self.assertEqual(client.delete(trash_path, headers=a).status_code, 200)
            self.assertEqual(client.get(path, headers=a).status_code, 404)
            self.assertEqual(client.get("/watch/comparison?days=7&end_date=2027-01-01", headers=a).status_code, 200)
            self.assertEqual(client.get("/watch/comparison?days=8", headers=a).status_code, 400)
            self.assertEqual(client.get("/watch/backup-policy", headers=a).status_code, 200)

    def test_streamlit_history_confirmation_and_last_record_deletion(self):
        from streamlit.testing.v1 import AppTest
        root = Path(__file__).resolve().parent.parent
        sys.path.insert(0, str(root / "streamlit_clock_update"))
        self.addCleanup(sys.path.remove, str(root / "streamlit_clock_update"))
        app = AppTest.from_file(str(root / "streamlit_clock_update" / "app.py"), default_timeout=45)
        app.session_state["auth_token"] = login("history-a", "test-password-123")["token"]
        app.run()
        self.assertFalse(app.exception)
        self.assertTrue(app.button(key=f"delete_record_{self.sid}").disabled)
        history = app.selectbox(key=f"coaching_history_{self.sid}")
        self.assertEqual(history.value, "coach-2")
        history.set_value("coach-1").run()
        self.assertTrue(any(m.value == "가상 조언 1" for m in app.markdown))
        app.checkbox(key="confirm_coaching_coach-1").check().run()
        app.button(key="delete_coaching_coach-1").click().run()
        self.assertFalse(app.exception)
        self.assertEqual(len(coaching_service.list_coaching(self.a["id"], self.sid)), 1)
        app.checkbox(key=f"confirm_record_{self.sid}").check().run()
        app.button(key=f"delete_record_{self.sid}").click().run()
        self.assertFalse(app.exception)
        self.assertEqual(list_sessions(self.a["id"]), [])
        self.assertTrue(any("아직 내 기록이 없습니다" in m.value for m in app.info))
        app.radio(key="main_menu").set_value("휴지통·백업").run()
        self.assertFalse(app.exception)
        self.assertTrue(app.button(key=f"purge_session_{self.sid}").disabled)
        app.button(key=f"restore_session_{self.sid}").click().run()
        self.assertFalse(app.exception)
        app.button(key="restore_coaching_coach-1").click().run()
        self.assertFalse(app.exception)
        app.radio(key="main_menu").set_value("기간별 비교").run()
        self.assertFalse(app.exception)
        self.assertEqual(len(app.dataframe[0].value), 2)
        app.radio(key="main_menu").set_value("새 분석").run()
        self.assertFalse(app.exception)
        app.radio(key="main_menu").set_value("과거 기록").run()
        self.assertFalse(app.exception)
        self.assertEqual(len(coaching_service.list_coaching(self.a["id"], self.sid)), 2)
        with patch.object(coaching_service, "settings", return_value=("fake", "test-alias")), patch.object(coaching_service, "OpenAI") as client:
            client.return_value.__enter__.return_value.responses.create.return_value = SimpleNamespace(status="completed", output_text="새 가상 코칭", model="test-resolved-model")
            next(button for button in app.button if button.label == "AI 조언 생성").click().run()
        self.assertFalse(app.exception)
        selected = app.selectbox(key=f"coaching_history_{self.sid}").value
        latest = coaching_service.latest_coaching(self.a["id"], self.sid)
        self.assertEqual(selected, latest["id"])
        self.assertEqual(latest["context"]["model"], "test-resolved-model")
        self.assertEqual(app.dataframe[0].value.iloc[0]["저장된 코칭"], 3)


if __name__ == "__main__":
    unittest.main()
