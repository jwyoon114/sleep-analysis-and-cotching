from contextlib import closing
import json
from pathlib import Path
import tempfile
import unittest

from health_records import connect, import_export, parse_export, same_observation
from json_sleep import parse_json_export

FILES = Path(r"C:\Users\jwyoo\Documents\카카오톡 받은 파일")
STEM = "2026-11-05-0000_to_2026-11-05-1033"
MD = FILES / f"health-export-md-{STEM}.md"
JSON = FILES / f"health-export-json-{STEM}.json"


def fixture():
    return {"meta": {"schemaVersion": 2, "timeZone": "Asia/Seoul", "rangeStart": "2026-11-04T15:00:00Z", "rangeEnd": "2026-11-05T01:33:52Z"},
            "sleep": {"sessions": [{"source": "Test Watch", "start": "23:00:00", "end": "07:00:00", "stages": [
                {"stage": "asleepCore", "start": "23:00:00", "end": "00:00:00"},
                {"stage": "asleepREM", "start": "00:00:00", "end": "07:00:00"}]}],
                "streams": {"heartRate": {"tupleSchema": ["time", "value", "sourceIdx"], "sources": ["Test Watch"], "unit": "bpm", "samples": [["23:30:00", 60, 0]]}}}}


class KitTest(unittest.TestCase):
    def test_overnight_overlapping_export_range(self):
        parsed = parse_json_export(json.dumps(fixture()))
        session = parsed["sessions"][0]
        self.assertEqual(session["start"], "2026-11-04T23:00:00+09:00")
        self.assertEqual(session["end"], "2026-11-05T07:00:00+09:00")
        self.assertEqual(session["asleep_minutes"], 480)
        self.assertEqual(parsed["samples"][0]["start"], "2026-11-04T23:30:00+09:00")

    def test_md_short_times_across_midnight(self):
        text = """# Health Data Export
- range: 2026-11-05 00:00 → 2026-11-05 10:33
- timezone: Asia/Seoul
## Session 1 — 23:00:00 → 07:00:00 (8h 00m)
- source: Test Watch
### Stages (2 segments)
```csv
time,stage,durationMin
23:00:00,core,60
00:00:00,rem,420
```
"""
        record = parse_export(text)["sessions"][0]
        self.assertEqual(record["start"], "2026-11-04T23:00:00+09:00")
        self.assertEqual(record["segments"][1]["start"], "2026-11-05T00:00:00+09:00")
        self.assertEqual(record["asleep_minutes"], 480)

    def test_bad_tuple_and_ambiguous_date_rejected(self):
        data = fixture()
        data["sleep"]["streams"]["heartRate"]["samples"][0][-1] = 99
        with self.assertRaisesRegex(ValueError, "sourceIdx"):
            parse_json_export(json.dumps(data))
        data = fixture()
        data["meta"]["rangeEnd"] = "2026-11-07T01:00:00Z"
        with self.assertRaisesRegex(ValueError, "날짜"):
            parse_json_export(json.dumps(data))

    def test_conflicting_sample_rejects_import(self):
        with tempfile.TemporaryDirectory() as tmp:
            db = Path(tmp) / "records.sqlite3"
            data = fixture()
            import_export(json.dumps(data), "first.json", db_path=db)
            data["sleep"]["streams"]["heartRate"]["samples"][0][1] = 80
            with self.assertRaisesRegex(ValueError, "생체지표"):
                import_export(json.dumps(data), "second.json", db_path=db)
            with closing(connect(db)) as connection:
                self.assertEqual(connection.execute("SELECT count(*) FROM imports").fetchone()[0], 1)

    @unittest.skipUnless(MD.is_file() and JSON.is_file(), "Actual user export pair is not present")
    def test_actual_pair_parse_and_dedup_in_both_orders(self):
        md = MD.read_text(encoding="utf-8-sig")
        js = JSON.read_text(encoding="utf-8-sig")
        a, b = parse_export(md), parse_json_export(js)
        self.assertEqual(len(a["sessions"]), 1)
        self.assertEqual(len(b["sessions"]), 1)
        self.assertEqual(len(a["samples"]), 225)
        self.assertEqual(len(b["samples"]), 225)
        self.assertEqual(len(a["sessions"][0]["segments"]), 36)
        self.assertTrue(same_observation(a["sessions"][0], b["sessions"][0]))
        self.assertAlmostEqual(a["sessions"][0]["asleep_minutes"], b["sessions"][0]["asleep_minutes"])
        for first, second in [[(md, MD.name), (js, JSON.name)], [(js, JSON.name), (md, MD.name)]]:
            with tempfile.TemporaryDirectory() as tmp:
                db = Path(tmp) / "records.sqlite3"
                self.assertEqual(import_export(*first, db_path=db)["added_sessions"], 1)
                self.assertEqual(import_export(*second, db_path=db)["added_sessions"], 0)
                with closing(connect(db)) as connection:
                    for table, count in [("sessions", 1), ("stages", 36), ("samples", 225)]:
                        self.assertEqual(connection.execute(f"SELECT count(*) FROM {table}").fetchone()[0], count)


if __name__ == "__main__":
    unittest.main()
