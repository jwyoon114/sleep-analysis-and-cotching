from contextlib import closing
from datetime import datetime, timedelta, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import zipfile

import coaching_service
import health_records
from health_records import connect, delete_session, import_export, list_sessions
from service_limits import CoachingLimitError, reserve_coaching_request
from sleep_accounts import delete_account, register
from test_health_records import FIXTURE

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from cloud_deploy.build_release import build_release
from cloud_deploy.start_cloud import bootstrap, validate_environment


class CloudDeploymentTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.data = self.root / "persistent-data"
        self.data.mkdir()
        self.db = self.data / "sleep.sqlite3"
        patcher = patch.object(health_records, "DB_PATH", self.db)
        patcher.start()
        self.addCleanup(patcher.stop)
        env = patch.dict(os.environ, {"SLEEP_DATA_DIR": str(self.data), "SLEEP_DB_PATH": str(self.db), "COACHING_USER_LIMIT_24H": "0", "COACHING_GLOBAL_LIMIT_24H": "0", "COACHING_MAX_INPUT_BYTES": "64000", "PORT": "10000"})
        env.start()
        self.addCleanup(env.stop)

    def test_mount_validation_blocks_ephemeral_or_outside_database(self):
        self.assertEqual(validate_environment()[0], self.db)
        for overrides in ({"SLEEP_DATA_DIR": ""}, {"SLEEP_DATA_DIR": "relative"}, {"SLEEP_DATA_DIR": str(self.root / "absent")}, {"SLEEP_DB_PATH": str(self.root / "outside.sqlite3")}, {"PORT": "0"}, {"PORT": "invalid"}, {"SLEEP_DATA_DIR": str(ROOT / "cloud_deploy"), "SLEEP_DB_PATH": str(ROOT / "cloud_deploy" / "unsafe.sqlite3")}):
            with patch.dict(os.environ, overrides), self.assertRaises(ValueError):
                validate_environment()
        self.assertFalse(self.db.exists())

    def test_bootstrap_restart_preserves_records_and_creates_managed_backup(self):
        self.assertEqual(bootstrap(), 10000)
        user = register("cloud-test", "test-password-123")
        import_export(FIXTURE, "fake.md", user["id"])
        bootstrap()
        self.assertEqual(len(list_sessions(user["id"])), 1)
        self.assertEqual(len(list(self.data.glob("*.managed-*.bak"))), 1)

    def test_user_limit_and_expired_requests(self):
        a = register("limit-user-a", "test-password-123")
        b = register("limit-user-b", "test-password-123")
        with patch.dict(os.environ, {"COACHING_USER_LIMIT_24H": "1", "COACHING_GLOBAL_LIMIT_24H": "3"}):
            reserve_coaching_request(a["id"])
            with self.assertRaises(CoachingLimitError):
                reserve_coaching_request(a["id"])
            reserve_coaching_request(b["id"])
            with closing(connect()) as db, db:
                db.execute("UPDATE coaching_requests SET requested_at=?", ((datetime.now(timezone.utc) - timedelta(hours=25)).isoformat(),))
            reserve_coaching_request(a["id"])
        with closing(connect()) as db:
            self.assertEqual(db.execute("SELECT count(*) FROM coaching_requests").fetchone()[0], 1)

    def test_deleted_account_is_anonymized_without_resetting_global_limit(self):
        a = register("limit-user-a", "test-password-123")
        b = register("limit-user-b", "test-password-123")
        with patch.dict(os.environ, {"COACHING_USER_LIMIT_24H": "10", "COACHING_GLOBAL_LIMIT_24H": "1"}):
            reserve_coaching_request(a["id"])
            delete_account(a["id"], "test-password-123", "계정 삭제")
            with self.assertRaises(CoachingLimitError):
                reserve_coaching_request(b["id"])
        with closing(connect()) as db:
            self.assertIsNone(db.execute("SELECT account_id FROM coaching_requests").fetchone()[0])

    def test_oversized_input_and_quota_never_call_paid_api(self):
        user = register("limit-user-a", "test-password-123")
        sid = import_export(FIXTURE, "fake.md", user["id"])["analysis_ids"][0]
        with patch.dict(os.environ, {"COACHING_MAX_INPUT_BYTES": "1"}), patch.object(coaching_service, "OpenAI") as client:
            with self.assertRaisesRegex(ValueError, "너무 큽니다"):
                coaching_service.generate(user["id"], sid, {})
            client.assert_not_called()
        with patch.dict(os.environ, {"COACHING_USER_LIMIT_24H": "1"}), patch.object(coaching_service, "settings", return_value=("fake", "fake-model")), patch.object(coaching_service, "OpenAI") as client:
            reserve_coaching_request(user["id"])
            with self.assertRaises(CoachingLimitError):
                coaching_service.generate(user["id"], sid, {})
            client.assert_not_called()

    def test_deleted_reference_cannot_be_saved_in_new_context(self):
        user = register("limit-user-a", "test-password-123")
        sid = import_export(FIXTURE, "fake.md", user["id"])["analysis_ids"][0]
        second = import_export(FIXTURE.replace("Test Watch", "Second Watch"), "fake.md", user["id"])["analysis_ids"][0]
        def response(**kwargs):
            delete_session(second, user["id"])
            return SimpleNamespace(status="completed", output_text="가상 코칭")
        with patch.object(coaching_service, "settings", return_value=("fake", "fake-model")), patch.object(coaching_service, "OpenAI") as client:
            client.return_value.__enter__.return_value.responses.create.side_effect = response
            with self.assertRaisesRegex(ValueError, "참고한 분석 기록"):
                coaching_service.generate(user["id"], sid, {})
        with closing(connect()) as db:
            self.assertEqual(db.execute("SELECT count(*) FROM coaching").fetchone()[0], 0)

    def test_release_is_allowlisted_and_boots_in_separate_process(self):
        output, archive = build_release(self.root / "releases")
        manifest = json.loads((output / "release_manifest.json").read_text(encoding="utf-8"))
        for name, expected in manifest["files"].items():
            self.assertEqual(hashlib.sha256((output / name).read_bytes()).hexdigest(), expected)
        with zipfile.ZipFile(archive) as package:
            names = package.namelist()
            self.assertIn("render.yaml", names)
            self.assertIn("service_limits.py", names)
            self.assertNotIn(".streamlit/secrets.toml", names)
            self.assertFalse(any("sqlite" in name or name.endswith(".bak") or "data/" in name or "desktop_launcher" in name for name in names))
            self.assertEqual(set(names), set(manifest["files"]) | {"release_manifest.json"})
        result = subprocess.run([sys.executable, "-B", str(output / "start_cloud.py"), "--check-only"], cwd=output, capture_output=True, text=True, encoding="utf-8", timeout=45)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("CLOUD_STORAGE_READY", result.stdout)
        # Verify packaged UI imports only from its own folder, against a fake DB.
        script = "from streamlit.testing.v1 import AppTest; s=AppTest.from_file('app.py', default_timeout=45).run(); assert not s.exception; assert len(s.text_input)==5; print('PACKAGED_LOGIN_OK')"
        result = subprocess.run([sys.executable, "-B", "-c", script], cwd=output, capture_output=True, text=True, encoding="utf-8", timeout=60)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("PACKAGED_LOGIN_OK", result.stdout)


if __name__ == "__main__":
    unittest.main()
