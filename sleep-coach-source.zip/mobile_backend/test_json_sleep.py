import json
from pathlib import Path
import tempfile
import unittest
from health_records import import_export, list_sessions, parse_export
from json_sleep import EXAMPLE_JSON, parse_json_export, to_json_export
from test_health_records import FIXTURE


class JsonSleepTest(unittest.TestCase):
    def test_recompute_totals_and_vitals(self):
        data = json.loads(EXAMPLE_JSON)
        data["sessions"][0]["asleep_minutes"] = 999999
        parsed = parse_json_export(json.dumps(data))["sessions"][0]
        self.assertEqual(parsed["asleep_minutes"], 55)
        self.assertEqual(parsed["awake_minutes"], 5)
        self.assertEqual(parsed["vitals_summary"][0]["n"], "2")

    def test_md_json_roundtrip_dedup(self):
        parsed = parse_export(FIXTURE)
        with tempfile.TemporaryDirectory() as tmp:
            db = Path(tmp) / "sleep.sqlite3"
            import_export(FIXTURE, "record.md", db_path=db)
            self.assertEqual(import_export(to_json_export(parsed), "record.json", db_path=db)["added_sessions"], 0)
            self.assertEqual(len(list_sessions(db_path=db)), 1)

    def test_explicit_offsets_are_respected(self):
        data = json.loads(EXAMPLE_JSON)
        data["sessions"][0]["segments"][0]["start"] = "2026-11-01T14:00:00Z"
        parsed = parse_json_export(json.dumps(data))["sessions"][0]
        self.assertEqual(parsed["asleep_minutes"], 55)
        self.assertEqual(parsed["segments"][0]["start"], "2026-11-01T23:00:00+09:00")

    def test_reject_malformed_naive_overlapping_unknown_stage(self):
        variants = ["[]", "{}", "invalid", '{"schema_version":1,"timezone":"invalid","sessions":[]}']
        for mutation in ["time", "overlap", "stage", "vital"]:
            data = json.loads(EXAMPLE_JSON)
            if mutation == "time":
                data["sessions"][0]["start"] = "2026-11-01T23:00:00"
            elif mutation == "overlap":
                data["sessions"][0]["segments"][1]["start"] = "2026-11-01T23:10:00+09:00"
            elif mutation == "stage":
                data["sessions"][0]["segments"][0]["stage"] = "N2"
            else:
                data["sessions"][0]["vitals_summary"][0]["avg"] = float("nan")
            variants.append(json.dumps(data))
        for value in variants:
            with self.subTest(value=value[:60]), self.assertRaises(ValueError):
                parse_json_export(value)

    def test_gaps_and_failed_import_leave_no_partial_sessions(self):
        data = json.loads(EXAMPLE_JSON)
        data["sessions"][0]["segments"][0]["end"] = "2026-11-01T23:10:00+09:00"
        self.assertEqual(parse_json_export(json.dumps(data))["sessions"][0]["unrecorded_minutes"], 10)
        data["sessions"].append({"start": "invalid"})
        with tempfile.TemporaryDirectory() as tmp:
            db = Path(tmp) / "sleep.sqlite3"
            with self.assertRaises(ValueError):
                import_export(json.dumps(data), "bad.json", db_path=db)
            self.assertFalse(list_sessions(db_path=db))


if __name__ == "__main__":
    unittest.main()
