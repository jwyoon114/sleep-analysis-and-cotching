# 나의 수면 리포트 · 계정 기반 수면 분석과 AI 코칭

Health Data Export의 수면 Markdown(.md), Health Export Kit JSON v2(.json), 수면 JSON v1(.json)을 업로드하고 분석하는 서비스입니다.
JSON 구조와 예제는 [JSON_FORMAT.md](JSON_FORMAT.md)를 참고하세요.
원시 EEG, EDF 파일, Random Forest 모델이나 학습용 PhysioNet 데이터가 필요하지 않습니다.
Apple 건강 앱의 표준 XML/ZIP 내보내기는 현재 지원하지 않습니다.

## 사용 흐름

1. 회원가입 → 로그인
2. 자신의 수면 .md 파일 업로드 → 분석하고 내 기록에 저장
3. 날짜별 수면·각성 합계, 단계별 시간, 시작·종료 시각과 생체지표 요약 확인
4. 연령 구분·카페인·규칙성·만족도 입력 → OpenAI 조언 생성
5. 재로그인 후 기록과 이전 조언 다시 조회
6. 조회 기간과 기록을 선택해 과거 분석 확인 → 생성 시각별 AI 코칭 선택
7. 필요하면 확인란을 체크한 뒤 분석 기록 또는 선택한 코칭 삭제

왼쪽 메뉴에서 **과거 기록 / 새 분석 / 기간별 비교 / 휴지통·백업 / 계정 설정**을 선택합니다.
과거 기록 목록에는 날짜·수면량·코칭 개수를 표시합니다.
기간별 비교는 기준일까지의 7일 또는 30일과 직전 같은 길이 기간을 비교합니다.
날짜별 수면·각성 합계와 기록별 시작 시각을 표시하며, 미기록 날짜는 빈 값으로 남깁니다.

삭제한 분석과 연결된 코칭은 휴지통에서 30일 동안 복원할 수 있습니다.
코칭만 개별 삭제할 수도 있습니다. 분석을 복원해도 이전에 따로 삭제한 코칭은
휴지통에 남습니다. 코칭을 복원하려면 연결된 분석을 먼저 복원해야 합니다.
휴지통에 있는 분석을 재업로드하면 복원 안내를 반환합니다.
30일이 지난 항목은 다음 로그인·앱 이용·인증 API 요청 시 해당 계정 범위에서 정리합니다.
휴지통의 영구 삭제는 확인란을 체크한 뒤 실행하며, 실행 후 복원할 수 없습니다.

신규 AI 코칭에는 사용한 모델·지침 버전·기록 범위·기록 수·생성 당시 요약을 저장합니다.
기능 추가 전 코칭의 생성 근거는 추측해 채우지 않습니다.

### 백업 및 영구 삭제

- 업데이트 전 SQLite 백업을 만들며, 관리 대상 DB 백업은 30일 보관합니다.
- 관리 대상은 DB와 같은 폴더의 `DB파일명.before-accounts-*.bak`, `DB파일명.managed-*.bak`입니다.
- 앱 업데이트 및 ‘휴지통·백업’ 화면 이용 시 만료 백업을 정리합니다. 앱 종료 중에는 정리 작업이 실행되지 않습니다.
- 영구 삭제는 앱 DB와 관리 대상 백업에 반영합니다. 파일 잠금 등으로 백업 정리가 실패하면 대기 건수를 표시하고 재시도합니다.
- 분석에 직접 연결된 코칭·단계·가져오기 연결과, 다른 분석이 사용하지 않는 해당 구간 안의 표본을 정리합니다.
- 다른 코칭의 생성 근거에 삭제한 분석이 포함되어 있으면 그 요약 사본도 제거합니다. 다른 코칭 문장에 간접 반영된 내용까지 재작성하지는 않습니다.
- 삭제 내역 재시도를 위해 종류·기록 식별자·계정 식별자·삭제 시각만 별도 보관합니다. 원시 기록·코칭 본문은 포함하지 않습니다.
- 사용자가 새로 업로드한 같은 기록은 새 저장으로 구분하여 이후 백업에서 보존합니다.
- 원본 MD·JSON, 다운로드 파일, 외부 복사본은 관리 범위 밖입니다. 물리적 저장 장치의 복구 불가능성을 보장하지 않습니다.

### 계정 편집 및 삭제

- ‘계정 설정’에서 아이디와 비밀번호를 각각 변경할 수 있습니다. 변경에는 현재 비밀번호가 필요합니다.
- 아이디는 문자·숫자·밑줄·점·하이픈 3~40자, 비밀번호는 10~128자입니다. 아이디의 앞뒤 공백과 대소문자를 정규화하고 중복 아이디를 거부합니다.
- 변경 후 모든 로그인 토큰을 폐기합니다. 변경한 정보로 다시 로그인하면 기존 기록·코칭·휴지통이 유지됩니다.
- 현재 비밀번호 확인에 10분 내 5회 실패하면 계정 변경·삭제도 일시 제한합니다. 실패 횟수는 로그인 제한과 공유합니다.
- 계정 삭제는 현재 비밀번호, ‘계정 삭제’ 문구, 화면의 영구 삭제 동의를 확인합니다. 계정 삭제에는 휴지통 복원 기간이 없습니다.
- 계정·로그인 토큰·해당 계정의 분석·코칭·휴지통·원시 표본 전체를 삭제합니다. 세션 밖의 표본도 포함합니다. 다른 계정은 유지합니다.
- 관리 대상 백업에서도 해당 계정의 계정 정보와 데이터를 제거합니다. 백업 정리가 실패하면 결과에 대기 건수를 반환하며, 웹 로그인 화면에서 재시도할 수 있습니다. 이후 백업 관리 실행 때도 재시도합니다.
- 백업 삭제 반영을 위해 계정 UUID와 삭제 시각을 삭제 목록에 보관합니다. 아이디·비밀번호 해시·건강 기록은 이 목록에 저장하지 않습니다.
- 같은 아이디로 다시 가입해도 새 계정 UUID를 발급하며 이전 기록은 복원되지 않습니다. 원본·다운로드·외부 복사본은 삭제 범위 밖입니다.

각 계정의 내부 ID로 기록을 분리하며 다른 이용자가 입력한 별칭으로 기록을 조회하지 않습니다.
기존 `apple_watch_owner` 별칭의 5건은 DB에 보존되며 새 계정에 자동 공개되지 않습니다.
처음 로그인한 뒤 기존 .md 파일을 한 번 올리면 본인 계정의 기록으로 저장됩니다.
기존 파일과 DB는 업데이트 전에 백업합니다.

## 실행

실제 바탕화면 프로젝트에는 `deploy_watch.ps1`로 반영합니다.
다른 PC에서는 이 폴더의 `api.py`, `health_records.py`, `json_sleep.py`, `export_times.py`,
`health_export_kit.py`, `sleep_accounts.py`,
`coaching_service.py`, `service_limits.py`, `history_service.py`, `backup_policy.py`, `requirements-mobile.txt`와 `streamlit_clock_update`의
`app.py`, `apple_watch_ui.py`를 같은 폴더에 둡니다.

```powershell
python -m pip install -r requirements-mobile.txt
python -m streamlit run app.py
```

모바일 앱용 서버:

```powershell
python -m uvicorn api:app --host 127.0.0.1 --port 8000
```

기존 서버가 실행 중이었다면 재시작해야 합니다. 같은 Wi-Fi의 휴대폰에서 연결하려면
개발 서버의 host를 `0.0.0.0`으로 바꾸고 PC 내부 IP를 앱에 입력합니다.
바탕화면 실행기는 기존대로 개인 PC의 localhost에 바인딩합니다. 인터넷 공개 배포는 하지 않았습니다.

인터넷 배포용 구성과 데이터 없는 패키지 생성은 [cloud_deploy 안내](../cloud_deploy/README.md)를 참고하세요.
배포 패키지 준비와 실제 서버 공개는 별개입니다. 클라우드 기본 설정에는 계정당 10회·전체 100회의 최근 24시간 코칭 요청 한도와 64,000바이트 입력 요약 제한이 있습니다.
한도는 서버가 외부 AI 요청을 보내기 전에 검사하며 실패한 외부 요청도 집계합니다. 실제 금액 상한을 보장하지는 않습니다.

OpenAI 키는 서버 환경변수 `OPENAI_API_KEY` 또는 `.streamlit/secrets.toml`에서 읽습니다.
`OPENAI_MODEL`로 모델을 지정할 수 있으며 기본값은 기존과 같은 `gpt-4.1-mini`입니다.
키는 모바일 앱이나 응답에 포함하지 않습니다. 키·크레딧이 없어도 수면 분석과 저장은 됩니다.

## 데이터와 계정

- SQLite 위치: 실행 파일 옆 `data/sleep_records.sqlite3`
- `SLEEP_DB_PATH` 환경변수로 변경 가능. 웹앱과 서버가 같은 경로를 사용해야 함
- 비밀번호: 개별 salt + PBKDF2-SHA256 600,000회 해시
- 로그인 토큰: DB에 SHA256 해시만 저장, 유효기간 24시간, 로그아웃 시 폐기
- 동일 아이디로 10분 내 로그인 5회 실패하면 일시 제한
- 모든 기록/코칭 API는 Bearer 토큰과 소유권을 검사
- 새 계정에는 다른 계정 및 기존 비회원 기록이 보이지 않음
- 같은 계정에 같은 파일·세션·표본을 다시 올리면 중복 저장하지 않음

계정 복구·이메일 인증·인터넷 배포용 HTTPS 및 운영 모니터링은 이번 구현에 포함하지 않습니다.
건강 기록은 로컬 SQLite에 평문 저장됩니다. DB와 `.streamlit/secrets.toml`을 소스 배포에 포함하지 마세요.

## 분석 기준

기기에서 이미 추정한 core/deep/rem/wake/unspecified 단계를 보존합니다.
수면 구간의 시작·종료 시각으로 수면/각성 합계를 재계산하며, durationMin의 반올림
오차(3.1초 이내)는 인접 구간의 시각으로 보정합니다. 더 큰 간격은 미기록으로 남깁니다.
겹치는 구간은 거부합니다. core를 N1/N2로 바꾸거나 미분류 단계를 만들어내지 않습니다.

날짜별 합계는 수면 시작일 기준입니다. 같은 날의 여러 기록은 합산합니다.
평균은 기록이 있는 날짜에 대해서만 계산하며, 누락된 날짜를 수면 0시간으로 취급하지 않습니다.
이 값은 기록된 수면량이며 실제 하루 전체 수면량·수면검사 결과를 의미하지 않습니다.

AI에는 선택 기록과 최근 최대 14회 기록의 집계·생체지표 요약·생활습관 입력을 전달합니다.
계정 ID, 장치 이름, 구간 배열, 원시 생체지표 표본은 보내지 않습니다.
요청에 성공한 조언만 해당 계정의 기록에 저장합니다. 규칙 기반 조언으로 대체하지 않습니다.

## API

- `POST /auth/register`: `{username, password}`
- `POST /auth/login`: `{username, password}` → `{token, user}`
- `GET /auth/me`, `POST /auth/logout`
- `PATCH /auth/me`: `{current_password, new_username?, new_password?}` → 변경 후 모든 토큰 폐기, 재로그인 필요
- `DELETE /auth/me`: JSON 본문 `{current_password, confirmation: "계정 삭제"}` → 영구 삭제 및 백업 처리 상태 (로그인한 본인에게만 적용)
- `POST /watch/import` 또는 `/analyze`: multipart `file` (.md 또는 .json, 최대 10MiB)
- `GET /watch/sessions`: 내 기록과 기간 집계
- `GET /watch/sessions/{analysis_id}`: 내 기록 상세
- `GET /watch/sessions/{analysis_id}/coaching`: 마지막 조언 `result` 및 전체 코칭 목록 `history` (최신순, ID·생활습관 포함)
- `DELETE /watch/sessions/{analysis_id}`: 내 분석 및 연결된 코칭을 휴지통으로 이동 (`status=trashed`)
- `DELETE /watch/sessions/{analysis_id}/coaching/{coaching_id}`: 내 코칭 한 건을 휴지통으로 이동
- `GET /watch/trash`: 내 휴지통과 복원 기한
- `POST /watch/trash/{kind}/{record_id}/restore`: 복원 (`kind=session` 또는 `coaching`)
- `DELETE /watch/trash/{kind}/{record_id}`: 휴지통 항목 영구 삭제 및 백업 처리 상태
- `GET /watch/comparison?days=7&end_date=2026-11-05`: 7일/30일 비교 (미기록은 null)
- `GET /watch/backup-policy`: 관리 백업 정리 상태·보관 기간
- `POST /coach`: `{analysis_id, age_group, caffeine, regularity, satisfaction}`

`/health`, 회원가입, 로그인을 제외한 요청에 `Authorization: Bearer 로그인토큰`을 넣습니다.
Swagger의 Authorize에는 로그인 응답의 token만 입력하세요.
이전 EDF `/analyze` 계약을 수면 Markdown 업로드로 변경했으므로 모바일 소스도 함께 업데이트해야 합니다.

## 검증

```powershell
python -B -m unittest discover -s mobile_backend -p "test_*.py" -v
python -B mobile_backend/verify_multiuser.py
```

암호·토큰, 계정 분리, 교차 계정 조회/조언 거부, 중복 업로드, 연도 경계, 미기록 처리,
조언 저장을 테스트합니다. 실제 OpenAI 호출은 모의 응답으로 대체합니다.
통합 테스트는 임시 DB와 로컬 HTTP 서버로 실행하며 실제 파일이 있으면 그 파일을 사용합니다.
