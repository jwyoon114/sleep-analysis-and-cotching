$ErrorActionPreference = 'Stop'
$project = 'C:\Users\jwyoo\Desktop\인하대 2-2\PythonProject1'
$workspace = Split-Path -Parent $PSScriptRoot
$stamp = [guid]::NewGuid().ToString('N')
$python = Join-Path $project '.venv\Scripts\python.exe'
# SQLite's backup API gives a consistent snapshot even if the app has been open.
& $python -B -c "import sqlite3,pathlib; p=pathlib.Path(r'$project')/'data'/'sleep_records.sqlite3'; src=sqlite3.connect(p) if p.exists() else None; dst=sqlite3.connect(str(p)+'.before-accounts-$stamp.bak') if src else None; src.backup(dst) if src else None; dst.close() if dst else None; src.close() if src else None"
if ($LASTEXITCODE -ne 0) { throw 'Database backup failed; update stopped.' }
foreach ($pair in @(
    @((Join-Path $workspace 'streamlit_clock_update\app.py'), 'app.py'),
    @((Join-Path $workspace 'streamlit_clock_update\apple_watch_ui.py'), 'apple_watch_ui.py'),
    @((Join-Path $PSScriptRoot 'api.py'), 'api.py'),
    @((Join-Path $PSScriptRoot 'health_records.py'), 'health_records.py'),
    @((Join-Path $PSScriptRoot 'json_sleep.py'), 'json_sleep.py'),
    @((Join-Path $PSScriptRoot 'export_times.py'), 'export_times.py'),
    @((Join-Path $PSScriptRoot 'health_export_kit.py'), 'health_export_kit.py'),
    @((Join-Path $PSScriptRoot 'sleep_accounts.py'), 'sleep_accounts.py'),
    @((Join-Path $PSScriptRoot 'coaching_service.py'), 'coaching_service.py'),
    @((Join-Path $PSScriptRoot 'service_limits.py'), 'service_limits.py'),
    @((Join-Path $PSScriptRoot 'history_service.py'), 'history_service.py'),
    @((Join-Path $PSScriptRoot 'backup_policy.py'), 'backup_policy.py')
)) {
    $target = Join-Path $project $pair[1]
    if (Test-Path -LiteralPath $target) {
        Copy-Item -LiteralPath $target -Destination ($target + '.before-watch-' + $stamp + '.bak')
    }
    Copy-Item -LiteralPath $pair[0] -Destination $target
}
Push-Location -LiteralPath $project
try {
    & $python -B -c "from health_records import connect; db=connect(); print('DB_SCHEMA_READY'); print('PRESERVED_SESSIONS:',db.execute('SELECT count(*) FROM sessions').fetchone()[0]); db.close(); import api; from backup_policy import maintain_backups; status=maintain_backups(); print('BACKUP_POLICY:',status); print('SERVICE:',api.app.title)"
    if ($LASTEXITCODE -ne 0) { throw 'Installed app verification failed.' }
} finally { Pop-Location }
Write-Output 'ACCOUNT_BASED_SLEEP_APP_INSTALLED'
