"""Local HTTP and Streamlit account-isolation integration checks. No paid API calls."""
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
from contextlib import closing

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT.parent / "streamlit_clock_update"))
from test_health_records import FIXTURE
from health_records import parse_export
from json_sleep import to_json_export

example = Path(r"C:\Users\jwyoo\Documents\카카오톡 받은 파일\health-export-md-2026-11-05-0000_to_2026-11-05-1033.md")
native_json = example.with_name("health-export-json-2026-11-05-0000_to_2026-11-05-1033.json")
input_text = example.read_text(encoding="utf-8-sig") if example.is_file() else FIXTURE
expected_sessions = len(parse_export(input_text)["sessions"])

with tempfile.TemporaryDirectory() as tmp:
    db_path = Path(tmp) / "records.sqlite3"
    with closing(socket.socket()) as sock:
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
    import health_records
    health_records.DB_PATH = db_path
    import api
    import uvicorn
    server = uvicorn.Server(uvicorn.Config(api.app, host="127.0.0.1", port=port, log_level="error"))
    worker = threading.Thread(target=server.run, daemon=True)
    worker.start()
    base = f"http://127.0.0.1:{port}"

    def request(path, data=None, token=None, content_type="application/json", expected=200):
        headers = {"Content-Type": content_type}
        if token:
            headers["Authorization"] = "Bearer " + token
        body = json.dumps(data).encode() if data is not None and not isinstance(data, bytes) else data
        req = urllib.request.Request(base + path, data=body, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=15) as response:
                assert response.status == expected, (path, response.status)
                return json.load(response)
        except urllib.error.HTTPError as error:
            assert error.code == expected, (path, error.code, error.read().decode())
            return json.load(error)

    try:
        for _ in range(100):
            try:
                request("/health")
                break
            except OSError:
                time.sleep(.1)
        else:
            raise RuntimeError("API did not start")
        request("/watch/sessions", expected=401)
        for name in ["test-user-a", "test-user-b"]:
            request("/auth/register", {"username": name, "password": "test-password-123"}, expected=201)
        a = request("/auth/login", {"username": "test-user-a", "password": "test-password-123"})
        b = request("/auth/login", {"username": "test-user-b", "password": "test-password-123"})
        boundary = "SleepTestBoundary"
        content = (f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="test.md"\r\nContent-Type: text/markdown\r\n\r\n' + input_text + f"\r\n--{boundary}--\r\n").encode()
        imported = request("/watch/import", content, a["token"], "multipart/form-data; boundary=" + boundary)
        sid = imported["analysis_ids"][0]
        assert request("/analyze", content, a["token"], "multipart/form-data; boundary=" + boundary)["added_sessions"] == 0
        json_input = native_json.read_text(encoding="utf-8-sig") if example.is_file() and native_json.is_file() else to_json_export(parse_export(input_text))
        json_content = (f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="test.json"\r\nContent-Type: application/json\r\n\r\n' + json_input + f"\r\n--{boundary}--\r\n").encode()
        assert request("/analyze", json_content, a["token"], "multipart/form-data; boundary=" + boundary)["added_sessions"] == 0
        assert len(request("/watch/sessions", token=a["token"])["sessions"]) == expected_sessions
        assert not request("/watch/sessions?subject=" + a["user"]["id"], token=b["token"])["sessions"]
        request("/watch/sessions/" + sid, token=b["token"], expected=404)
        request("/watch/sessions/" + sid + "/coaching", token=b["token"], expected=404)
        request("/coach", {"analysis_id": sid}, b["token"], expected=404)
        request("/auth/logout", {}, b["token"])
        request("/watch/sessions", token=b["token"], expected=401)
        print("HTTP_OK: registration, login, upload, dedup, cross-account denial, logout")

        import health_records
        health_records.DB_PATH = db_path
        from streamlit.testing.v1 import AppTest
        screen = AppTest.from_file(str(ROOT.parent / "streamlit_clock_update" / "app.py"), default_timeout=45).run()
        assert not screen.exception, [e.message for e in screen.exception]
        assert screen.title[0].value == "나의 수면 리포트"
        assert len(screen.text_input) == 5
        screen.text_input(key="login_name").set_value("test-user-a")
        screen.text_input(key="login_password").set_value("test-password-123")
        screen.button[0].click().run()
        assert not screen.exception, [e.message for e in screen.exception]
        assert len(screen.dataframe[0].value) == expected_sessions
        assert any(m.label == "기기 추정 수면 시간" for m in screen.metric)
        screen.sidebar.button[0].click().run()
        assert not screen.exception
        assert len(screen.text_input) == 5
        print("STREAMLIT_OK: logged-out screen, login, own dashboard, logout")
    finally:
        server.should_exit = True
        worker.join(timeout=10)
        assert not worker.is_alive(), "Test HTTP server did not shut down"
