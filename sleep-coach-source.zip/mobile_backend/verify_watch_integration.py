"""Compatibility entry point for the account-based integration verification."""
import runpy
from pathlib import Path

runpy.run_path(str(Path(__file__).with_name("verify_multiuser.py")), run_name="__main__")
