@echo off
setlocal
if not exist "%~dp0backend\.venv\Scripts\pythonw.exe" exit /b 1
start "" /b "%~dp0backend\.venv\Scripts\pythonw.exe" "%~dp0sleep_frontend\launch_web.py" --stop
