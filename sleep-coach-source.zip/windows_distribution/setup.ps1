param(
    [string]$PythonExecutable = '',
    [switch]$CheckOnly,
    [switch]$NoShortcuts
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$root = $PSScriptRoot
$backend = Join-Path $root 'backend'
$frontend = Join-Path $root 'sleep_frontend'

function Invoke-Checked {
    param([string]$Program, [string[]]$Arguments)
    & $Program @Arguments
    if ($LASTEXITCODE -ne 0) { throw "Command failed ($LASTEXITCODE): $Program" }
}

try {
    if (-not (Test-Path -LiteralPath (Join-Path $backend 'api.py'))) {
        throw 'Extract the entire ZIP first, then open SETUP.cmd inside that folder.'
    }
    $pythonPrefix = @()
    if ($PythonExecutable) {
        $python = (Get-Command $PythonExecutable -ErrorAction Stop).Source
    } elseif (Get-Command py.exe -ErrorAction SilentlyContinue) {
        $python = (Get-Command py.exe).Source
        $pythonPrefix = @('-3')
    } elseif (Get-Command python.exe -ErrorAction SilentlyContinue) {
        $python = (Get-Command python.exe).Source
    } else {
        throw 'Install Python 3.11+ from https://www.python.org/downloads/windows/ and run SETUP.cmd again.'
    }
    Invoke-Checked $python ($pythonPrefix + @('-c', 'import sys;sys.exit(sys.version_info<(3,11))'))
    $node = Get-Command node.exe -ErrorAction SilentlyContinue
    $npm = Get-Command npm.cmd -ErrorAction SilentlyContinue
    if (-not $node -or -not $npm) {
        throw 'Install Node.js LTS from https://nodejs.org/en/download then reopen SETUP.cmd.'
    }
    $nodeVersion = & $node.Source --version
    if ($LASTEXITCODE -ne 0 -or $nodeVersion -notmatch '^v(\d+)\.(\d+)\.') {
        throw 'Could not check the Node.js version.'
    }
    if ([int]$Matches[1] -lt 20 -or ([int]$Matches[1] -eq 20 -and [int]$Matches[2] -lt 9)) {
        throw 'Node.js 20.9+ is required. Install the current LTS version.'
    }
    if ($CheckOnly) {
        Write-Host 'PREREQUISITES_OK'
        exit 0
    }
    Write-Host '[1/4] Preparing a private Python environment...'
    $venvPython = Join-Path $backend '.venv\Scripts\python.exe'
    if (-not (Test-Path -LiteralPath $venvPython)) {
        Invoke-Checked $python ($pythonPrefix + @('-m', 'venv', (Join-Path $backend '.venv')))
    }
    Write-Host '[2/4] Installing Python dependencies...'
    Invoke-Checked $venvPython @('-m', 'pip', 'install', '-r', (Join-Path $backend 'requirements-mobile.txt'))
    Write-Host '[3/4] Installing and building the web app (first setup can take several minutes)...'
    Push-Location -LiteralPath $frontend
    $oldTelemetry = $env:NEXT_TELEMETRY_DISABLED
    try {
        $env:NEXT_TELEMETRY_DISABLED = '1'
        Invoke-Checked $npm.Source @('ci', '--no-audit', '--no-fund')
        Invoke-Checked $npm.Source @('run', 'build')
    } finally {
        $env:NEXT_TELEMETRY_DISABLED = $oldTelemetry
        Pop-Location
    }
    Write-Host '[4/4] Creating desktop shortcuts...'
    if (-not $NoShortcuts) {
        & (Join-Path $frontend 'install-desktop.ps1') -BackendProjectPath $backend
    }
    Write-Host 'SETUP_COMPLETE. Open the Daljam desktop shortcut, or double-click START.cmd.'
} catch {
    Write-Host ('SETUP_FAILED: ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
}
