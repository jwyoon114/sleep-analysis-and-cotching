"""Draw a simple code-native moon icon for installable web app metadata."""
from pathlib import Path
from PIL import Image,ImageDraw
root=Path(__file__).resolve().parents[1]/'sleep_frontend/public/icons'
root.mkdir(parents=True,exist_ok=True)
for name,size in [('app-192.png',192),('app-512.png',512),('app-maskable.png',512),('apple-touch-icon.png',180)]:
    scale=4
    s=size*scale
    im=Image.new('RGB',(s,s),'#7861ac')
    d=ImageDraw.Draw(im)
    d.ellipse((s*.24,s*.22,s*.76,s*.74),fill='#fff5df')
    d.ellipse((s*.40,s*.14,s*.88,s*.62),fill='#7861ac')
    x,y,r=s*.67,s*.65,s*.055
    d.polygon([(x,y-r),(x+r*.3,y-r*.3),(x+r,y),(x+r*.3,y+r*.3),(x,y+r),(x-r*.3,y+r*.3),(x-r,y),(x-r*.3,y-r*.3)],fill='#fff5df')
    im.resize((size,size),Image.Resampling.LANCZOS).save(root/name)
print('PWA_ICONS_CREATED')
