"""Build an explicit source-only Windows installer bundle; never include user data."""
import hashlib
import json
import os
from pathlib import Path
import re
import zipfile

ROOT = Path(__file__).resolve().parents[1]
BACKEND = ('api.py', 'health_records.py', 'json_sleep.py', 'export_times.py',
           'health_export_kit.py', 'sleep_accounts.py', 'coaching_service.py',
           'service_limits.py', 'history_service.py', 'backup_policy.py',
           'requirements-mobile.txt', 'sleep_alarms.py', 'sleep_alarm_popup.py')
FRONTEND = ('package.json', 'package-lock.json', 'tsconfig.json', 'next.config.ts',
            'launch_web.py', 'install-desktop.ps1', 'share_phone.py', 'PHONE_APP.md')
SECRET = re.compile(r'(?:sk-(?:proj-)?[A-Za-z0-9_-]{24,}|gh[pousr]_[A-Za-z0-9]{30,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)')

def build():
    sources = {f'backend/{name}': ROOT / 'mobile_backend' / name for name in BACKEND}
    sources.update({f'sleep_frontend/{name}': ROOT / 'sleep_frontend' / name for name in FRONTEND})
    sources['desktop_launcher/launch_sleep_app.py'] = ROOT / 'desktop_launcher/launch_sleep_app.py'
    sources['free_share/download-cloudflared.ps1'] = ROOT / 'free_share/download-cloudflared.ps1'
    for name in ('sw.js','offline.html','icons/app-192.png','icons/app-512.png','icons/app-maskable.png','icons/apple-touch-icon.png'):
        sources['sleep_frontend/public/'+name] = ROOT / 'sleep_frontend/public' / name
    for name in ('SETUP.cmd', 'START.cmd', 'STOP.cmd', 'setup.ps1', 'README.md'):
        sources[name] = ROOT / 'windows_distribution' / name
    for folder, directories, filenames in os.walk(ROOT / 'sleep_frontend/src', followlinks=False):
        for name in directories:
            if (Path(folder) / name).is_symlink():
                raise ValueError('Symlink directory is not allowed')
        for name in filenames:
            source = Path(folder) / name
            if source.suffix not in ('.ts', '.tsx', '.css', '.svg', '.ico'):
                raise ValueError('Unexpected frontend source: ' + name)
            sources[source.relative_to(ROOT).as_posix()] = source
    files = {}
    for target, source in sources.items():
        if source.is_symlink() or not source.is_file():
            raise ValueError('Expected a regular source file: ' + target)
        content = source.read_bytes()
        if source.suffix not in ('.ico','.png') and SECRET.search(content.decode('utf-8-sig')):
            raise ValueError('Possible secret in ' + target)
        if source.suffix == '.py':
            compile(content, target, 'exec')
        # Windows PowerShell 5 handles Unicode scripts reliably with a BOM.
        if source.suffix == '.ps1':
            content = b'\xef\xbb\xbf' + content.decode('utf-8-sig').encode('utf-8')
        if source.suffix == '.cmd':
            content = content.replace(b'\r\n', b'\n').replace(b'\n', b'\r\n')
        files[target] = content
    manifest = {name: hashlib.sha256(raw).hexdigest() for name, raw in files.items()}
    files['source_manifest.json'] = json.dumps(manifest, ensure_ascii=False, indent=2).encode('utf-8')
    output = ROOT / 'github_upload/artifacts/daljam-windows-setup.zip'
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as archive:
        for name, raw in sorted(files.items()):
            archive.writestr('Daljam/' + name, raw)
    with zipfile.ZipFile(output) as archive:
        assert archive.testzip() is None
        for name, digest in manifest.items():
            assert hashlib.sha256(archive.read('Daljam/' + name)).hexdigest() == digest
    print('VERIFIED_FILES', len(files))
    print('PACKAGE', output)

if __name__ == '__main__':
    build()
