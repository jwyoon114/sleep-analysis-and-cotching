"""Export the phone PWA project without enabling or bundling external sharing."""
import hashlib
import json
from pathlib import Path
import zipfile
from build_package import build, ROOT

README = '''# 달잠 휴대폰 웹앱(PWA) 프로젝트

아이폰·안드로이드의 지원 브라우저에서 홈 화면에 설치하는 웹앱의 소스입니다.
이 ZIP 자체를 휴대폰에서 설치하는 APK·IPA 파일은 아닙니다.

## 현재 상태

- 모바일 반응형 화면, 앱 이름·아이콘·설치 정보와 설치 안내 구현
- 로그인·기록 분석·그래프·AI 코칭을 위한 Python 서버 포함
- 개인 기록을 서비스 워커 캐시에 저장하지 않는 오프라인 안내 구현
- 웹앱 빌드와 모바일 너비, 설치 정보·접근 제한 검증 완료
- 실제 아이폰·안드로이드에서의 설치 검증은 미실시
- 외부 공유·공개 서버 배포·휴대폰 접속 주소 생성은 하지 않음

## 폴더

- sleep_frontend: Next.js 기반 휴대폰 웹앱 소스와 설치 아이콘
- backend: Python API 및 계정별 데이터 관리, AI 코칭
- desktop_launcher: 로컬 Windows 실행기에서 사용하는 도구

## PC에서 미리보기

Python 3.11 이상과 Node.js LTS를 설치하고 ZIP을 전체 압축 해제합니다.
Windows에서 SETUP.cmd를 실행하면 필요한 구성요소를 설치·빌드합니다.
START.cmd는 PC 안의 http://127.0.0.1:3000 을 엽니다.
이 주소를 휴대폰에 입력하면 해당 PC에 연결되는 것이 아닙니다.
이 묶음에는 인터넷 공유 실행기나 터널 다운로드 도구를 포함하지 않았습니다.

## 나중에 휴대폰에서 사용하기

휴대폰에서 접근 가능한 HTTPS 주소와 서버 실행 환경을 별도로 준비해야 합니다.
서버 연결 후 아이폰은 Safari → 공유 → 홈 화면에 추가,
안드로이드는 Chrome·삼성 인터넷 → 메뉴 → 앱 설치 / 홈 화면에 추가를 이용합니다.
OS·브라우저 버전에 따라 지원 여부와 메뉴 이름이 다를 수 있습니다.

## 데이터 및 제한

기존 계정·수면 기록·API 키·로그·백업은 포함하지 않았습니다.
AI 코칭에는 사용하는 서버의 유효한 API 키와 사용 가능한 크레딧이 필요합니다.
기존 취침·기상 알람은 서버 Windows PC에서 울리는 기능입니다.
휴대폰 기본 알람이나 백그라운드 푸시 알람은 구현되어 있지 않습니다.
인터넷 연결 없이 기록을 분석하는 앱도 아닙니다.
'''

def export():
    build()
    source=ROOT/'github_upload/artifacts/daljam-windows-setup.zip'
    output=source.with_name('daljam-phone-pwa-source.zip')
    files={}
    with zipfile.ZipFile(source) as archive:
        for name in archive.namelist():
            path=name.removeprefix('Daljam/')
            if path in {'source_manifest.json','README.md','sleep_frontend/share_phone.py','sleep_frontend/PHONE_APP.md'} or path.startswith('free_share/'):
                continue
            files[path]=archive.read(name)
    files['README.md']=README.encode('utf-8')
    hashes={name:hashlib.sha256(raw).hexdigest() for name,raw in files.items()}
    files['source_manifest.json']=json.dumps(hashes,ensure_ascii=False,indent=2).encode('utf-8')
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as archive:
        for name,raw in sorted(files.items()):archive.writestr('Daljam-PWA/'+name,raw)
    with zipfile.ZipFile(output) as archive:
        assert archive.testzip() is None
        for name,digest in hashes.items():assert hashlib.sha256(archive.read('Daljam-PWA/'+name)).hexdigest()==digest
        assert not any('share_phone' in name or '/free_share/' in name or '/.runtime/' in name or '/data/' in name for name in archive.namelist())
    print('PHONE_PWA_SOURCE_VERIFIED',len(files))
    print('EXTERNAL_SHARING_NOT_STARTED')

if __name__=='__main__':export()
