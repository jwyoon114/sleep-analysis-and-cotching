"""Shared SQLite/PostgreSQL operations. Explicit file paths always select SQLite."""
import os
import re
import threading


def cloud_database(db_path=None):
    return db_path is None and bool(os.getenv("DATABASE_URL"))


def begin_write(db):
    if isinstance(db, PostgresConnection):
        # Transaction-scoped: works with Neon's transaction pooler, too.
        db.execute("SELECT pg_advisory_xact_lock(731412809)")
    else:
        db.execute("BEGIN IMMEDIATE")


def secure_delete(db):
    if not isinstance(db, PostgresConnection):
        db.execute("PRAGMA secure_delete=ON")


def table_names(db):
    query = ("SELECT table_name FROM information_schema.tables WHERE table_schema=current_schema()"
             if isinstance(db, PostgresConnection) else "SELECT name FROM sqlite_master WHERE type='table'")
    return {row[0] for row in db.execute(query)}


class Record(dict):
    """Preserve sqlite3.Row's named and positional access."""
    def __getitem__(self, key):
        return tuple(self.values())[key] if isinstance(key, (int, slice)) else super().__getitem__(key)


def record_factory(cursor):
    names = [column.name for column in cursor.description] if cursor.description else []
    return lambda values: Record(zip(names, values))


def postgres_sql(query):
    # Application queries use qmark parameters, ordinary quoted strings and
    # identifiers only. Leave quoted contents untouched. END needs quoting in PG.
    tokens = re.split(r"('(?:[^']|'')*'|\"(?:[^\"]|\"\")*\")", query)
    number = 0
    def parameter(_):
        nonlocal number
        number += 1
        return f"${number}"
    for index in range(0, len(tokens), 2):
        tokens[index] = re.sub(r"\?", parameter, tokens[index])
        tokens[index] = re.sub(r"\bend\b", '"end"', tokens[index], flags=re.I)
    return "".join(tokens)


class PostgresConnection:
    def __init__(self, connection):
        self.connection = connection

    def execute(self, query, parameters=None):
        return self.connection.execute(postgres_sql(query), parameters)

    def executemany(self, query, parameters):
        cursor = self.connection.cursor()
        cursor.executemany(postgres_sql(query), parameters)
        return cursor

    def executescript(self, script):
        for statement in script.split(";"):
            if statement.strip():
                self.execute(statement)
        self.connection.commit()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, traceback):
        if exc_type is None:
            self.connection.commit()
        else:
            self.connection.rollback()

    def close(self):
        self.connection.close()


_schema_lock = threading.Lock()
_initialized_url = None


def connect_postgres(schema):
    import psycopg
    from psycopg.conninfo import conninfo_to_dict
    global _initialized_url
    url = os.environ["DATABASE_URL"]
    options = conninfo_to_dict(url)
    if options.get("sslmode") not in {"require", "verify-ca", "verify-full"}:
        raise ValueError("DATABASE_URL에 SSL 연결 설정(sslmode=require)이 필요합니다.")
    connection = psycopg.connect(url, cursor_factory=psycopg.RawCursor,
                                row_factory=record_factory, connect_timeout=20,
                                options="-c statement_timeout=30000 -c lock_timeout=20000")
    db = PostgresConnection(connection)
    try:
        with _schema_lock:
            if _initialized_url != url:
                begin_write(db)
                # No SQLite pragmas or REAL's reduced precision on PostgreSQL.
                ddl = re.sub(r"PRAGMA user_version = 1;", "", schema)
                ddl = re.sub(r"\bREAL\b", "DOUBLE PRECISION", ddl)
                db.executescript(ddl)
                _initialized_url = url
        return db
    except BaseException:
        db.close()
        raise
