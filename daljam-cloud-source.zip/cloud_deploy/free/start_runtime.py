"""Run the internal API and public Next server; shut down both on failure."""
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
from urllib.request import urlopen


def validate_environment():
    if not os.getenv("DATABASE_URL", "").startswith(("postgres://", "postgresql://")):
        raise ValueError("DATABASE_URL에 외부 PostgreSQL 연결을 설정하세요. 로컬 DB로 대체하지 않습니다.")
    port = int(os.getenv("PORT", "10000"))
    if not 1024 <= port <= 65535 or port == 8011:
        raise ValueError("공개 서버 포트 설정을 확인하세요.")
    return port


def main():
    children = []
    try:
        port = validate_environment()
        os.environ.update(SLEEP_CLOUD="1", SLEEP_DESKTOP_ALARMS="0",
                          SLEEP_API_URL="http://127.0.0.1:8011", NODE_ENV="production")
        sys.path.insert(0, "/app/backend")
        from sleep_alarms import connect
        db = connect()
        db.close()
        children.append(subprocess.Popen([sys.executable, "-m", "uvicorn", "api:app",
                         "--host", "127.0.0.1", "--port", "8011", "--no-access-log"], cwd="/app/backend"))
        ready = False
        for _ in range(120):
            if children[0].poll() is not None:
                break
            try:
                with urlopen("http://127.0.0.1:8011/health", timeout=1) as response:
                    ready = response.status == 200
            except OSError:
                pass
            if ready:
                break
            time.sleep(0.5)
        if not ready:
            raise RuntimeError("내부 API를 시작하지 못했습니다.")
        env = os.environ | {"PORT": str(port), "HOSTNAME": "0.0.0.0", "NODE_OPTIONS": "--max-old-space-size=256"}
        children.append(subprocess.Popen(["node", "server.js"], cwd="/app/web", env=env))
        while all(child.poll() is None for child in children):
            time.sleep(1)
        raise RuntimeError("서버 프로세스가 종료됐습니다.")
    except KeyboardInterrupt:
        return 0
    except Exception:
        # Connection exceptions can contain hosts/usernames; never print them.
        print("CLOUD_START_FAILED: DB 연결·SSL 설정과 서버 빌드 상태를 확인하세요.", flush=True)
        return 1
    finally:
        for child in children:
            if child.poll() is None:
                child.terminate()
        for child in children:
            try:
                child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait()


if __name__ == "__main__":
    signal.signal(signal.SIGTERM, lambda *_: (_ for _ in ()).throw(KeyboardInterrupt()))
    sys.exit(main())
