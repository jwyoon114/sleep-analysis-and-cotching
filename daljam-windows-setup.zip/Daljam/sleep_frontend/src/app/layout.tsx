import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "달잠 · 나의 수면 리포트",
  description: "나의 밤을 이해하고, 더 편안한 내일을 준비하는 수면 기록과 AI 코칭",
  robots: { index: false, follow: false },
};

export default function RootLayout({ children }: Readonly<{children: React.ReactNode}>) {
  return <html lang="ko"><body>{children}</body></html>;
}
