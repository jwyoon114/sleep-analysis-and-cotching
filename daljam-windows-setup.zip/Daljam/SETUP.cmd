@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1"
if errorlevel 1 (
  echo Setup failed. See the message above.
) else (
  echo Setup complete. Double-click START.cmd to open the app.
)
pause
